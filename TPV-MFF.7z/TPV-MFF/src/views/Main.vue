<template>
  <div class="wrapper">
    <Main-layout>
      <div slot="sider" class="sider-top" style="color:orangered"> ( 这里是侧边菜单栏的自定义未收起前的顶部 ) </div>
      <div slot="sider-collapsed" class="sider-top" style="color:orangered">( 这里是侧边菜单栏的自定义收起后的顶部 )</div>
      <div slot="header-left" style="color:orangered"> ( 头部左侧自定义拓展 ) </div>
      <div slot="header-right" style="color:orangered"> ( 头部右侧自定义拓展 ) </div>
    </Main-layout>
  </div>
</template>

<script>
import MainLayout from '@/components/layout/main'
export default {
  name: 'index',
  components: {
    MainLayout
  },
  props: {},
  data () {
    return {}
  },
  created () { },
  mounted () {
  },
  updated () { },
  destroyed () { },
  methods: {},
  computed: {},
  watch: {}
}
</script>
<style lang="less" scoped>
.wrapper {
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  width: 100%;
}
</style>
