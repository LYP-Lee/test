import Loading from './loading'
export default {
  install (Vue) {
    Vue.mixin({
      created () {
        this.$loading = Loading
      }
    })
  }
}