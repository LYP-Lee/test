export default {
  state: {
    theme: {
      sider: 'dark', // bright/dark
      header: 'bright'// bright/dark/main
    },
    nav: {
      collapsedBtn: true,
      breadcrumb: true,
      fullScreen: true,
      language: true
    },
    others: {
      tagsNav: true
    }
  },
  getters: {

  },
  mutations: {
    setSiderTheme (state, type) {
      state.theme.sider = type
    },
    setHeaderTheme (state, type) {
      state.theme.header = type
    },
    setNav (state, data) {
      state.nav = data
    },
    setOthers (state, data) {
      state.others = data
    }
  },
  actions: {
    setSiderTheme ({ state, commit }, type) {
      commit('setSiderTheme', type)
    },
    setHeaderTheme ({ state, commit }, type) {
      commit('setHeaderTheme', type)
    },
    setNav ({ state, commit }, data) {
      commit('setNav', data)
    },
    setOthers ({ state, commit }, data) {
      commit('setOthers', data)
    }
  }
}
