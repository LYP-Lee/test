export default {
  state: {
    userName: '',
    access: ''
  },
  mutations: {
    setUserName (state, name) {
      state.userName = name
    }
  },
  getters: {
  },
  actions: {
    getUserInfo ({ state, commit }) {
      // commit('setUserName', data.name)
    }
  }
}
