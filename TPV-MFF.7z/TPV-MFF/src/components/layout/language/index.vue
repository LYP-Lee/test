<template>
  <div>
    <Dropdown trigger="click" @on-click="selectLang">
      <a href="javascript:void(0)">
        {{ title }}
        <Icon :size="18" type="md-arrow-dropdown" />
      </a>
      <DropdownMenu slot="list">
        <DropdownItem v-for="(value, key) in localList" :name="key" :key="`lang-${key}`">{{ value }}</DropdownItem>
      </DropdownMenu>
    </Dropdown>
  </div>
</template>

<script>
export default {
  name: 'Language',
  props: {
  },
  data () {
    return {
      lang: this.$i18n.locale,
      langList: {
        'zh': '语言',
        'zh-TW': '語言',
        'en': 'Lang'
      },
      localList: {
        'zh': '中文简体',
        'zh-TW': '中文繁体',
        'en': 'English'
      }
    }
  },
  created () {
  },
  watch: {
    lang (lang) {
      this.$i18n.locale = lang
    }
  },
  computed: {
    title () {
      return this.langList[this.lang]
    }
  },
  methods: {
    selectLang (name) {
      this.lang = name
      this.$emit('selectLang', name)
    }
  }
}
</script>
