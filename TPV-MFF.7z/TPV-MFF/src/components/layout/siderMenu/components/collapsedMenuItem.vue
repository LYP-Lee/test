<template>
  <Dropdown
    :transfer="!title"
    placement="right-start"
    @on-click="handleSelected"
    transfer-class-name="menu-dropdown"
  >
    <a href="javascript:void(0)" class="dropdown-title" :class="{'dropdown-box':title}">
      <template v-if="itemData.meta.icon || title">
        <Common-icon :icon="itemData.meta.icon" :size="size" :color="color"></Common-icon>
        <span v-if="title" :class="{'dropdown-title-box':title}">{{ title }}</span>
      </template>
      <template v-else>
        <Common-icon icon="md-help" :size="size" :color="color"></Common-icon>
      </template>
      <Common-icon
        icon="ios-arrow-forward"
        :size="size"
        :color="color"
        v-if="itemData.children && itemData.children.length > 0 && title"
      ></Common-icon>
    </a>
    <DropdownMenu slot="list">
      <template v-for="(item,index) in itemData.children">
        <template v-if="item.children && item.children.length > 0">
          <collapsedMenuItem
            :itemData="item"
            :key="`${item.name}_${index}`"
            :title="$t(`router.${item.name}`)"
          ></collapsedMenuItem>
        </template>
        <template v-else>
          <DropdownItem :name="item.name" :key="`${item.name}_${index}`">
            <Common-icon :icon="item.meta.icon"></Common-icon>
            {{ $t(`router.${item.name}`) }}
          </DropdownItem>
        </template>
      </template>
    </DropdownMenu>
  </Dropdown>
</template>

<script>
import CommonIcon from '@/components/commonIcon'
export default {
  name: 'collapsedMenuItem',
  components: {
    CommonIcon
  },
  props: {
    itemData: {
      type: Object
    },
    title: {
      type: String
    }
  },
  data () {
    return {
      size: 26,
      color: '#fff'
    }
  },
  created () {
    if (this.title) {
      this.size = 18
      this.color = '#515a6e'
    }
  },
  mounted () {
    let menuDropdown = document.getElementsByClassName('menu-dropdown')
    menuDropdown.forEach((item) => {
      item.style.overflow = 'visible'
      item.style.maxHeight = '600px'
    })
  },
  updated () { },
  destroyed () { },
  methods: {
    handleSelected (name) {
      this.$emit('handleSelect', name)
    }
  },
  computed: {
  },
  watch: {}
}
</script>
<style lang="less" scoped>
.ivu-dropdown {
  width: 100%;
  text-align: center;
}
.dropdown-title {
  display: block;
  width: 100%;
}
.dropdown-box {
  text-align: left;
  color: #515a6e;
  font-size: 14px;
  padding: 7px 0 7px 16px;
}
</style>
