<template>
    <div class="header-base-menu-wrapper">
        <div class="header-menu-item" v-if="$store.state.setting.nav.fullScreen">
          <Full-screen-components></Full-screen-components>
        </div>
        <div class="header-menu-item" v-if="$store.state.setting.nav.language">
          <Language></Language>
        </div>
        <div class="header-menu-item">
          <User></User>
        </div>
        <div class="header-menu-item">
          <Setting-drawer></Setting-drawer>
        </div>
    </div>
</template>

<script>
import User from '@/components/layout/user'
import Language from '@/components/layout/language'
import FullScreenComponents from '@/components/fullScreen'
import SettingDrawer from '@/components/layout/settingDrawer'
export default {
  name: 'headerBaseMenu',
  components: {
    User,
    Language,
    FullScreenComponents,
    SettingDrawer
  },
  props: {
  },
  data () {
    return {
      isShowSettingDrawer: false
    }
  },
  created () {},
  mounted () {},
  updated () {},
  destroyed () {},
  methods: {},
  computed: {},
  watch: {}
}
</script>
<style lang="less" scoped>
.header-base-menu-wrapper{
    display: flex;
    align-items: center;
}
.header-menu-item{
    padding-left: 20px;
}
</style>
