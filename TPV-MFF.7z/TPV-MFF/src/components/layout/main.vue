<template>
  <Layout style="height: 100%" class="main">
    <Sider
      hide-trigger
      collapsible
      :width="256"
      :collapsed-width="64"
      v-model="collapsed"
      class="left-sider"
      :class="{'sider-theme-bright':themeSetting.sider==='bright' && themeFlag}"
    >
      <Sider-menu
        :activeName="$route.name"
        :openedNames="openedNames"
        :theme="'dark'"
        :collapsed="collapsed"
        :menuList="$store.getters.menuList"
      >
        <slot name="sider" v-if="!collapsed"></slot>
        <slot name="sider-collapsed" v-if="collapsed"></slot>
      </Sider-menu>
    </Sider>
    <Layout>
      <Header
        class="header-cont"
        :class="{'header-theme-main':themeSetting.header==='main' && themeFlag,'header-theme-dark':themeSetting.header==='dark' && themeFlag}"
      >
        <Header-bar>
          <template slot="left">
            <div
              class="collapsed-btn-box"
              :class="{'collapsed':collapsed}"
              @click="collapsed = !collapsed"
              v-if="$store.state.setting.nav.collapsedBtn"
            >
              <Common-icon v-if="collapsed" icon="md-menu" :size="24"></Common-icon>
              <Common-icon v-else icon="md-menu" :size="24"></Common-icon>
            </div>
            <slot name="header-left"></slot>
          </template>
          <template slot="right">
            <slot name="header-right"></slot>
          </template>
        </Header-bar>
      </Header>
      <Content class="main-content-cont">
        <Layout class="main-layout-cont">
          <div class="tag-nav-wrapper" v-if="$store.state.setting.others.tagsNav">
            <Tags-nav />
          </div>
          <Content class="content-wrapper" id="content">
            <keep-alive :exclude="$store.getters.notCacheList">
              <router-view v-if="$store.state.app.isRouteActive" />
            </keep-alive>
          </Content>
        </Layout>
      </Content>
    </Layout>
  </Layout>
</template>

<script>
import SiderMenu from '@/components/layout/siderMenu'
import HeaderBar from '@/components/layout/headerBar'
import TagsNav from '@/components/layout/tagsNav'// 该组件为全局路由组件，自定义数据组件可使用'@/components/layout/tagsNav/customTagsNav'
import CommonIcon from '@/components/commonIcon'
import configs from '@/libs/configs.js'
export default {
  name: 'mainLayout',
  components: {
    SiderMenu,
    HeaderBar,
    TagsNav,
    CommonIcon
  },
  props: {},
  data () {
    return {
      collapsed: false
    }
  },
  created () {
    this.initEvent()
    this.$store.dispatch('setCurrentRoute', this.$route)
  },
  mounted () {
    this.$loading.moveEl('content')
  },
  updated () { },
  destroyed () { },
  methods: {
    initEvent () {
      this.calCollapsed()
      window.onresize = () => {
        this.calCollapsed()
      }
    },
    calCollapsed () {
      if (window.innerWidth < 1200) {
        this.collapsed = true
      } else {
        this.collapsed = false
      }
    }
  },
  computed: {
    openedNames () {
      let currentMatched = this.$route.matched
      let arr = []
      for (let i = 0; i < currentMatched.length; i++) {
        arr.push(currentMatched[i].name)
      }
      return arr
    },
    themeSetting () {
      return this.$store.state.setting.theme
    },
    themeFlag () {
      return configs.theme
    }
  },
  watch: {
    '$route' (newRoute) {
      this.$store.dispatch('setCurrentRoute', newRoute)
    }
  }
}
</script>
<style lang="less" scoped>
.header-cont {
  background: #fff;
  padding-left: 30px;
  padding-right: 30px;
}
.tag-nav-wrapper {
  padding: 0;
  height: 40px;
  background: #f0f0f0;
}
.collapsed-btn-box {
  cursor: pointer;
}
.collapsed {
  transform: rotate(90deg);
}
.ivu-layout-content {
  height: calc(100% - 64px);
  overflow: hidden;
}
.main-layout-cont {
  height: 100%;
}
div.content-wrapper {
  position: relative;
  overflow: auto;
}
/*********************** 主题风格设置样式 **************************/
.header-theme-dark {
  background: #515a6e;
  /deep/.ivu-icon {
    color: rgba(255, 255, 255, 0.7);
  }
  /deep/.ivu-breadcrumb {
    a {
      color: #fff;
    }
  }
}
.header-theme-main {
  background: linear-gradient(90deg, #1d42ab, #2173dc, #1e93ff);
  /deep/.ivu-icon {
    color: rgba(255, 255, 255, 0.7);
  }
  /deep/a {
    color: rgba(255, 255, 255, 0.7);
    &:hover {
      color: #fff;
    }
  }
  /deep/.ivu-breadcrumb {
    a {
      color: #fff;
    }
  }
}
.sider-theme-bright {
  background: #fff;
  /deep/.ivu-menu-dark {
    background: #fff;
  }
  /deep/.ivu-menu-dark.ivu-menu-vertical .ivu-menu-item,
  /deep/.ivu-menu-dark.ivu-menu-vertical .ivu-menu-submenu-title {
    color: #515a6e;
  }
  /deep/.ivu-menu-dark.ivu-menu-vertical
    .ivu-menu-child-item-active
    > .ivu-menu-submenu-title {
    color: #515a6e;
  }
  /deep/.ivu-menu-dark.ivu-menu-vertical .ivu-menu-item,
  /deep/.ivu-menu-dark.ivu-menu-vertical .ivu-menu-submenu-title {
    color: #515a6e;
  }
  /deep/.ivu-menu-dark.ivu-menu-vertical
    .ivu-menu-submenu
    .ivu-menu-item-active,
  /deep/.ivu-menu-dark.ivu-menu-vertical
    .ivu-menu-submenu
    .ivu-menu-item-active:hover {
    position: relative;
    background: #f0faff !important;
    color: #2d8cf0;
    &:after {
      position: absolute;
      right: 0;
      top: 0;
      display: block;
      content: '';
      width: 2px;
      height: 100%;
      background: #2d8cf0;
    }
  }
  /deep/.ivu-menu-dark.ivu-menu-vertical
    .ivu-menu-item-active:not(.ivu-menu-submenu),
  /deep/.ivu-menu-dark.ivu-menu-vertical
    .ivu-menu-submenu-title-active:not(.ivu-menu-submenu),
  /deep/.ivu-menu-dark.ivu-menu-vertical
    .ivu-menu-item-active:not(.ivu-menu-submenu):hover,
  /deep/.ivu-menu-dark.ivu-menu-vertical
    .ivu-menu-submenu-title-active:not(.ivu-menu-submenu):hover {
    position: relative;
    background: #f0faff !important;
    color: #2d8cf0;
    &:after {
      position: absolute;
      right: 0;
      top: 0;
      display: block;
      content: '';
      width: 2px;
      height: 100%;
      background: #2d8cf0;
    }
  }
  /deep/.ivu-menu-dark.ivu-menu-vertical
    .ivu-menu-opened
    .ivu-menu-submenu-title {
    background: #fff;
  }
  /deep/.ivu-menu-dark.ivu-menu-vertical .ivu-menu-opened {
    background: #fff;
  }
  /deep/.ivu-menu-dark.ivu-menu-vertical .ivu-menu-item:hover,
  /deep/.ivu-menu-dark.ivu-menu-vertical .ivu-menu-submenu-title:hover {
    background: #fff;
    color: #2d8cf0;
  }
  /deep/.collapsed-menu .ivu-icon {
    color: #515a6e !important;
  }
}
/***************************** end *******************************/
</style>
