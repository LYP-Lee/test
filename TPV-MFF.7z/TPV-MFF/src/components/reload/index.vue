<template>
  <div class="reload-wrapper" @click="reloadPage()" :title="$t('common.refresh')">
    <Common-icon icon="ios-refresh" :size="26"></Common-icon>
  </div>
</template>

<script>
import CommonIcon from '@/components/commonIcon'
export default {
  name: 'reload',
  components: {
    CommonIcon
  },
  props: {
  },
  data () {
    return {
    }
  },
  created () {
  },
  mounted () {
  },
  updated () { },
  destroyed () { },
  methods: {
    reloadPage () {
      this.$store.dispatch('setIsRouteActive', false)
      this.$nextTick(() => {
        this.$store.dispatch('setIsRouteActive', true)
      })
    }
  },
  computed: {

  },
  watch: {}
}
</script>
<style lang="less" scoped>
.reload-wrapper {
  cursor: pointer;
  margin: 0 10px;
}
</style>
