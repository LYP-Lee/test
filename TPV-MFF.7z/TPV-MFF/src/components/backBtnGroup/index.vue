<template>
  <div class="back-btn-group">
    <Button size="large" type="text" @click="backHome">返回首页</Button>
    <Button size="large" type="text" @click="backPrev">返回上一页({{ second }}s)</Button>
  </div>
</template>

<script>
export default {
  name: 'backBtnGroup',
  data () {
    return {
      second: 5,
      timer: null
    }
  },
  methods: {
    backHome () {
      this.$router.replace({
        name: 'home'
      })
    },
    backPrev () {
      this.$router.go(-1)
    }
  },
  mounted () {
    let currentMatched = this.$route.matched
    let autoBackFlag = true
    currentMatched.forEach(element => {
      if (element.meta.noAutoBack) {
        autoBackFlag = false
      }
    })
    this.timer = setInterval(() => {
      if (this.second === 0) {
        if (!autoBackFlag) {
          clearInterval(this.timer)
          return
        }
        this.backPrev()
      } else this.second--
    }, 1000)
  },
  beforeDestroy () {
    clearInterval(this.timer)
  }
}
</script>
<style lang="less" scoped>
.back-btn-group{
  display: flex;
  align-items: center;
  justify-content: space-between;
}
</style>
