<template>
  <div class="fullScreen-wrapper">
    <Icon type="md-expand" size="24" @click="fullScreen()" v-if="!isFullScreen"/>
    <Icon type="md-contract" size="24" @click="exitFullScreen()" v-if="isFullScreen"/>
  </div>
</template>

<script>
import util from '@/libs/util'
export default {
  name: 'fullScreen',
  components: {
  },
  props: {
    id: {
      type: String
    }
  },
  data () {
    return {
      isFullScreen: false
    }
  },
  created () {
    this.initEvent()
  },
  mounted () {
  },
  updated () { },
  destroyed () { },
  methods: {
    fullScreen () {
      util.fullScreen(this.id)
    },
    exitFullScreen () {
      util.exitFullscreen()
    },
    initEvent () {
      document.addEventListener('fullscreenchange', () => {
        this.isFullScreen = !this.isFullScreen
        this.$emit('fullscreenchange', this.isFullScreen)
      })
      document.addEventListener('mozfullscreenchange', () => {
        this.isFullScreen = !this.isFullScreen
        this.$emit('fullscreenchange', this.isFullScreen)
      })
      document.addEventListener('webkitfullscreenchange', () => {
        this.isFullScreen = !this.isFullScreen
        this.$emit('fullscreenchange', this.isFullScreen)
      })
      document.addEventListener('msfullscreenchange', () => {
        this.isFullScreen = !this.isFullScreen
        this.$emit('fullscreenchange', this.isFullScreen)
      })
    }
  },
  computed: {

  },
  watch: {}
}
</script>
<style lang="less" scoped>
.fullScreen-wrapper{
  cursor: pointer;
}
</style>
