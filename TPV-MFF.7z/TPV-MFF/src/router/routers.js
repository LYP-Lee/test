import Main from '@/views/Main'
/**
 * meta除了原生参数外可配置的参数:
 * meta: {
 *  title: { String } 标题
 *  hideInBread: (false) 设为true后此级路由将不会出现在面包屑中
 *  hideInMenu: (false) 设为true后在左侧菜单不会显示该页面选项
 *  notCache: (false) 设为true后页面在切换标签后不会缓存，如果需要缓存，无需设置这个字段，而且需要设置页面组件name属性和路由配置的name一致
 *  access: (null) 可访问该页面的权限数组，当前路由设置的权限会影响子路由
 *  icon: (-) 该页面在左侧菜单、面包屑和标签导航处显示的图标，如果是自定义图标，需要在图标名称前加下划线'_',如果是图片，图标名称为'image_图片路径'
 * }
 */
export default [
  {
    path: '/login',
    name: 'login',
    meta: {
      title: '登录',
      hideInMenu: true
    },
    component: () => import('_t/views/Login')
  },
  {
    path: '/401',
    name: 'error_401',
    meta: {
      hideInMenu: true
    },
    component: () => import('_t/views/errorPage/401.vue')
  },
  {
    path: '/500',
    name: 'error_500',
    meta: {
      hideInMenu: true
    },
    component: () => import('_t/views/errorPage/500.vue')
  },
  {
    path: '*',
    name: 'error_404',
    meta: {
      hideInMenu: true
    },
    component: () => import('_t/views/errorPage/404.vue')
  },
  {
    path: '/',
    name: '_home',
    redirect: '/home',
    component: Main,
    meta: {
      hideInMenu: true,
      hideInBread: true,
      notCache: true
    },
    children: [
      {
        path: '/home',
        name: 'home',
        meta: {
          hideInMenu: true,
          title: '首页',
          notCache: true,
          icon: 'md-home'
        },
        component: () => import('_t/views/Home')
      }
    ]
  },
  {
    path: '/theme_main',
    name: 'themeMain',
    meta: {
      hideInBread: true
    },
    component: Main,
    children: [
      {
        path: '/theme',
        name: 'theme',
        meta: {
          title: '主题定制',
          icon: 'ios-shirt-outline'
        },
        component: () => import('_t/views/Theme')
      }
    ]
  },
  {
    path: '/add_routes',
    name: 'addRoutes',
    meta: {
      hideInBread: true
    },
    component: Main,
    children: [
      {
        path: '/add_routes_page',
        name: 'addRoutesPage',
        meta: {
          title: '动态添加路由',
          icon: 'ios-cog-outline'
        },
        component: () => import('_t/views/addRoutesPage')
      }
    ]
  },
  {
    path: '/full_screen_main',
    name: 'fullScreenMain',
    meta: {
      hideInBread: true
    },
    component: Main,
    children: [
      {
        path: '/fullScreen',
        name: 'fullScreen',
        meta: {
          title: '全屏',
          icon: 'md-expand'
        },
        component: () => import('_t/views/FullScreen')
      }
    ]
  },
  {
    path: '/components_page',
    name: 'componentsPage',
    meta: {
      title: '组件',
      icon: 'ios-cube-outline'
    },
    component: Main,
    children: [
      {
        path: 'common_icon',
        name: 'commonIcon',
        meta: {
          title: '图标',
          icon: 'ios-color-palette-outline'
        },
        component: () => import('_t/views/componentsPage/commonIcon')
      },
      {
        path: 'breadcrumb',
        name: 'breadcrumb',
        meta: {
          title: '面包屑'
        },
        component: () => import('_t/views/componentsPage/breadcrumb')
      }, {
        path: 'sider_menu',
        name: 'siderMenu',
        meta: {
          title: '侧边菜单'
        },
        component: () => import('_t/views/componentsPage/siderMenu')
      },
      {
        path: 'tags_nav',
        name: 'tagsNav',
        meta: {
          title: '标签导航'
        },
        component: () => import('_t/views/componentsPage/tagsNav')
      },
      {
        path: 'language',
        name: 'language',
        meta: {
          title: '语言'
        },
        component: () => import('_t/views/componentsPage/language')
      },
      {
        path: 'reload',
        name: 'reloadPage',
        meta: {
          title: '重载',
          icon: 'ios-refresh'
        },
        component: () => import('_t/views/componentsPage/reload')
      },
      {
        path: '/edit_page',
        name: 'editPage',
        meta: {
          title: '编辑器',
          icon: 'ios-create-outline'
        },
        component: () => import('_t/views/commonMain'),
        children: [
          {
            path: 'simplemde',
            name: 'simplemdePage',
            meta: {
              title: 'simplemde',
              noAutoBack: true
            },
            component: () => import('_t/views/editPage/simplemde.vue')
          },
          {
            path: 'quill',
            name: 'quillPage',
            meta: {
              title: 'quill',
              noAutoBack: true
            },
            component: () => import('_t/views/editPage/quill.vue')
          }
        ]
      },
      {
        path: '/select_main',
        name: 'selectMain',
        meta: {
          title: '下拉选择器',
          icon: 'ios-arrow-dropdown'
        },
        component: () => import('_t/views/commonMain'),
        children: [
          {
            path: 'vue_select',
            name: 'vueSelectPage',
            meta: {
              title: 'vue-select',
              noAutoBack: true
            },
            component: () => import('_t/views/selectPage/select.vue')
          },
          {
            path: 'vue_treeselect',
            name: 'treeSelectPage',
            meta: {
              title: 'vue-treeselect',
              noAutoBack: true
            },
            component: () => import('_t/views/selectPage/treeSelect.vue')
          }
        ]
      },
      {
        path: '/table_main',
        name: 'tableMain',
        meta: {
          title: '表格',
          icon: 'md-grid'
        },
        component: () => import('_t/views/commonMain'),
        children: [
          {
            path: '/vxe_table',
            name: 'vxeTablePage',
            meta: {
              title: 'vxe-table'
            },
            component: () => import('_t/views/tablePage/vxeTable.vue')
          }
        ]
      }
    ]
  },
  {
    path: '/tools_page',
    name: 'tollsPage',
    meta: {
      title: '工具页面',
      icon: 'ios-construct-outline'
    },
    component: Main,
    children: [
      {
        path: 'pdf',
        name: 'pdfPage',
        meta: {
          title: 'pdf',
          noAutoBack: true
        },
        component: () => import('_t/views/toolsPage/previewPDF.vue')
      },
      {
        path: 'move',
        name: 'movePage',
        meta: {
          title: '移动元素',
          icon: 'ios-move'
        },
        component: () => import('_t/views/toolsPage/move')
      },
      {
        path: '/draggable_main',
        name: 'draggableMain',
        meta: {
          title: '拖拽',
          icon: 'ios-move'
        },
        component: () => import('_t/views/commonMain'),
        children: [
          {
            path: '/vuedraggable',
            name: 'vuedraggable',
            meta: {
              title: 'vuedraggable'
            },
            component: () => import('_t/views/draggablePage/vuedraggable.vue')
          }
        ]
      },
      {
        path: 'compress_img',
        name: 'compressImgPage',
        meta: {
          title: '图片压缩'
        },
        component: () => import('_t/views/toolsPage/compressImg.vue')
      }
    ]
  },
  {
    path: '/directive_page',
    name: 'directivePage',
    meta: {
      title: '指令页面',
      icon: 'ios-paper-plane-outline'
    },
    component: Main,
    children: [
      {
        path: 'loading',
        name: 'loadingPage',
        meta: {
          title: '加载'
        },
        component: () => import('_t/views/directivePage/loading')
      }
    ]
  },
  {
    path: '/error_page',
    name: 'errorPage',
    meta: {
      title: '异常页面',
      icon: 'ios-warning-outline'
    },
    component: Main,
    children: [
      {
        path: '401',
        name: 'error_page_401',
        meta: {
          title: '401',
          noAutoBack: true,
          icon: 'ios-bug'
        },
        component: () => import('_t/views/errorPage/401.vue')
      },
      {
        path: '404',
        name: 'error_page_404',
        meta: {
          title: '404',
          noAutoBack: true,
          icon: 'ios-bug'
        },
        component: () => import('_t/views/errorPage/404.vue')
      },
      {
        path: '500',
        name: 'error_page_500',
        meta: {
          title: '500',
          noAutoBack: true,
          icon: 'ios-bug'
        },
        component: () => import('_t/views/errorPage/500.vue')
      }
    ]
  },
  {
    path: '/result_page',
    name: 'resultPage',
    meta: {
      title: '结果页面',
      icon: 'ios-checkmark-circle-outline'
    },
    component: Main,
    children: [
      {
        path: 'success',
        name: 'successPage',
        meta: {
          title: '成功',
          noAutoBack: true
        },
        component: () => import('_t/views/resultPage/success')
      },
      {
        path: 'failure',
        name: 'failurePage',
        meta: {
          title: '失败',
          noAutoBack: true
        },
        component: () => import('_t/views/resultPage/failure')
      }
    ]
  },
  {
    path: '/about',
    name: 'about',
    component: Main,
    meta: {
      title: '关于',
      notCache: true,
      icon: 'ios-alert-outline'
    },
    children: [
      {
        path: 'about_page',
        name: 'about_page',
        meta: {
          title: '关于',
          icon: `image_${require('@/assets/images/sider_menu_test.png')}`
        },
        component: () => import('@/views/About')
      }
    ]
  }
]
