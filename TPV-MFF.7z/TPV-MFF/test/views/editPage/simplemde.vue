<template>
  <div class="theme-wrapper">
    <div class="header">
      <h1>vue-simplemde编辑器组件</h1>
    </div>
    <div class="content">
      <div class="content-item">
        <h2>使用示例</h2>
        <p>
          <Vue-simplemde v-model="content" ref="markdownEditor" preview-class="markdown-body"></Vue-simplemde>
        </p>
        <p>
          <span style="color:orangered">内容：</span>
        </p>
        <p v-html="showContent"></p>
      </div>
      <div class="content-item">
        <h2>github地址</h2>
        <p>
          <a
            href="https://github.com/F-loat/vue-simplemde"
            target="parent"
          >https://github.com/F-loat/vue-simplemde</a>
        </p>
      </div>
      <div class="content-item">
        <h2>注意</h2>
        <p>vue-simplemde协议：vue-simplemde is open source and released under the MIT Licence.</p>
      </div>
    </div>
  </div>
</template>
<script>
import VueSimplemde from 'vue-simplemde'
export default {
  name: 'simplemdePage',
  data () {
    return {
      content: '',
      showContent: ''
    }
  },
  components: {
    VueSimplemde
  },
  computed: {
  },
  methods: {

  },
  watch: {
    content () {
      this.showContent = this.$refs.markdownEditor.simplemde.markdown(this.content)
    }
  },
  created () {

  },
  mounted () {
    // console.log(this.$refs.markdownEditor.simplemde);
    // this.$refs.markdownEditor.simplemde.togglePreview();
    // this.$refs.markdownEditor.simplemde.codemirror.on('beforeChange', (instance, changeObj) => {
    //   // do some things
    // });
    // this.$refs.markdownEditor.simplemde = null;
    // this.$refs.markdownEditor.$refs.markdownEditor.initialize(); // init
    // this.$refs.markdownEditor.simplemde.toTextArea();
    // this.$refs.markdownEditor.simplemde.isPreviewActive(); // returns boolean
    // this.$refs.markdownEditor.simplemde.isSideBySideActive(); // returns boolean
    // this.$refs.markdownEditor.simplemde.isFullscreenActive(); // returns boolean
    // this.$refs.markdownEditor.simplemde.clearAutosavedValue(); // no returned value
    // this.$refs.markdownEditor.simplemde.markdown(this.content); // returns parsed html
    // this.$refs.markdownEditor.simplemde.codemirror.refresh(); // refresh codemirror
  }
}
</script>
<style lang='less' scoped>
@import '~simplemde/dist/simplemde.min.css';
@import '~github-markdown-css';
.content-item {
  text-align: left;
  padding: 20px;
  p {
    padding-top: 10px;
  }
}
</style>>
