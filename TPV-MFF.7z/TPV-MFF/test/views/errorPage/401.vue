<template>
  <div class="error-wrapper">
    <Error-content code="401" desc="Oh~~您没有浏览这个页面的权限~" :src="src" />
  </div>
</template>

<script>
import error401 from '@/assets/images/error-page/error-401.svg'
import ErrorContent from '@/components/errorContent'
export default {
  name: 'error_page_401',
  components: {
    ErrorContent
  },
  data () {
    return {
      src: error401
    }
  }
}
</script>
<style lang="less" scoped>
.error-wrapper {
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}
</style>
