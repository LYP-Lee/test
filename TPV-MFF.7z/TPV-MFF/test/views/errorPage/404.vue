<template>
  <div class="error-wrapper">
    <Error-content code="404" desc="Oh~~您的页面好像飞走了~" :src="src" />
  </div>
</template>

<script>
import error404 from '@/assets/images/error-page/error-404.svg'
import ErrorContent from '@/components/errorContent'
export default {
  name: 'error_page_404',
  components: {
    ErrorContent
  },
  data () {
    return {
      src: error404
    }
  }
}
</script>
<style lang="less" scoped>
.error-wrapper {
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}
</style>
