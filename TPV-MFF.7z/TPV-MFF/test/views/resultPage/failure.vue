<template>
  <div class="result-wrapper">
    <Result type="failure" tip="请核对并修改以下信息后，再重新提交。" tipContent="这里是信息提示的补充">
      <div slot="content">这里是自定义的提示内容</div>
      <div slot="button">
        <Button>这里是自定义的按钮拓展</Button>
      </div>
    </Result>
  </div>
</template>
<script>
import Result from '@/components/result/index'
export default {
  name: 'failurePage',
  data () {
    return {}
  },
  components: {
    Result
  },
  computed: {

  },
  methods: {

  },
  created () {
  },
  mounted () {

  }
}
</script>
<style lang='less' scoped>
.result-wrapper {
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}
</style>
