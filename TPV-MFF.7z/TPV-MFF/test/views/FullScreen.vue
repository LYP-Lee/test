<template>
  <div class="full-screen-wrapper">
    <div class="header">
      <h1>全屏</h1>
    </div>
    <div class="content" id="fullScreen">
      <div class="content-item">
        <h2 class="content-item-title">使用</h2>
        <div class="content-item-box">
          <Button type="primary" @click="fullScreen()">全屏</Button>
          <Button type="default" @click="exitFullScreen()">退出全屏</Button>
          <Button type="primary" @click="fullScreen('fullScreen')">部分区域全屏</Button>
        </div>
        <div class="content-item-box">
          <div class="full-item-box">
            <span>全屏</span>
            <FullScreenComponents></FullScreenComponents>
          </div>
          <div class="full-item-box">
            <span>部分区域全屏</span>
            <FullScreenComponents id="fullScreen"></FullScreenComponents>
          </div>
        </div>
      </div>
      <div class="content-item">
        <h2 class="content-item-title">脚本使用说明</h2>
        <div class="content-item-box">
          <p>调用util.fullScreen()实现全屏；调用util.exitFullscreen()退出全屏</p>
          <p>fullScreen方法传入id则指定区域部分全屏，不传默认当前整个文档全屏显示</p>
        </div>
      </div>
      <div class="content-item">
        <h2 class="content-item-title">全屏组件使用说明</h2>
        <div class="content-item-box">
          <p>import FullScreenComponents from '@/components/fullScreen' 引入全屏组件</p>
          <p>传入id属性则区域部分全屏，不传默认当前整个文档全屏显示</p>
          <p>全屏/退出全屏事件监听，组件抛出fullscreenchange事件，参数为当前全屏状态</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import util from '@/libs/util'
import FullScreenComponents from '@/components/fullScreen'
export default {
  name: 'fullScreen',
  components: {
    FullScreenComponents
  },
  data () {
    return {
    }
  },
  methods: {
    fullScreen (id) {
      util.fullScreen(id)
    },
    exitFullScreen () {
      util.exitFullscreen()
    }
  }
}
</script>
<style lang="less" scoped>
.content{
  text-align: left;
  padding: 20px;
}
p{
  padding-top: 10px;
}
.content-item-box{
  padding: 20px 0;
  button{
    margin-right: 10px;
  }
}
.content{
  background: #f5f7f9;
}
</style>
