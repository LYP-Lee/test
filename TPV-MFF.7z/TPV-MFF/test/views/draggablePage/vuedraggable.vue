<template>
  <div class="theme-wrapper">
    <div class="header">
      <h1>vue-draggable组件</h1>
    </div>
    <div class="content">
      <div class="content-item">
        <h2>使用示例</h2>
        <p>
          <span>示例一(基础)</span>
          <draggable v-model="myArray" ghost-class="ghost">
            <div v-for="element in myArray" :key="element.id" class="list-item">{{element.name}}</div>
          </draggable>
        </p>
        <div>
          <span>示例二(两个列表)</span>
          <div class="list-container">
            <draggable v-model="list1" ghost-class="ghost" group="people">
              <div v-for="element in list1" :key="element.id" class="list-item">{{element.name}}</div>
            </draggable>
            <draggable v-model="list2" ghost-class="ghost" group="people" class="group">
              <div v-for="element in list2" :key="element.id" class="list-item">{{element.name}}</div>
            </draggable>
          </div>
        </div>
        <p>
          <span>示例三(过渡动画)</span>
          <draggable v-model="myArray" ghost-class="ghost" :animation="200">
            <transition-group>
              <div v-for="element in myArray" :key="element.id" class="list-item">{{element.name}}</div>
            </transition-group>
          </draggable>
        </p>
        <p>
          <span class="other-header">
            <span style="color:orangered">其它演示</span>
            <FullScreenComponents id="fullScreen"></FullScreenComponents>
          </span>
          <iframe
            src="https://sortablejs.github.io/Vue.Draggable/"
            class="iframe"
            id="fullScreen"
          >正在加载中。。。</iframe>
        </p>
      </div>
      <div class="content-item">
        <h2>演示地址</h2>
        <p>
          <a
            href="https://sortablejs.github.io/Vue.Draggable/"
            target="parent"
          >https://sortablejs.github.io/Vue.Draggable/</a>
        </p>
        <p>
          <a
            href="https://david-desmaisons.github.io/draggable-example/"
            target="parent"
          >https://david-desmaisons.github.io/draggable-example/</a>
        </p>
      </div>
      <div class="content-item">
        <h2>github地址</h2>
        <p>
          <a
            href="https://github.com/SortableJS/Vue.Draggable"
            target="parent"
          >https://github.com/SortableJS/Vue.Draggable</a>
        </p>
      </div>
      <div class="content-item">
        <h2>注意</h2>
        <p>协议：MIT Licence.</p>
      </div>
    </div>
  </div>
</template>
<script>

import draggable from 'vuedraggable'
import FullScreenComponents from '@/components/fullScreen'
export default {
  name: 'vuedraggable',
  data () {
    return {
      myArray: [{
        id: 11,
        name: '张三'
      }, {
        id: 22,
        name: '李四'
      }, {
        id: 33,
        name: '王五'
      }, {
        id: 44,
        name: '赵六'
      }],
      list1: [{
        id: 111,
        name: '一1'
      }, {
        id: 222,
        name: '一2'
      }, {
        id: 333,
        name: '一3'
      }],
      list2: [{
        id: 1111,
        name: '二1'
      }, {
        id: 2222,
        name: '二2'
      }, {
        id: 3333,
        name: '二3'
      }]
    }
  },
  components: {
    draggable,
    FullScreenComponents
  },
  computed: {
  },
  methods: {
  },
  watch: {
  },
  created () {

  },
  mounted () {
  }
}
</script>
<style lang='less' scoped>
.content-item {
  text-align: left;
  padding: 20px;
  p {
    padding-top: 10px;
  }
}
.iframe {
  display: block;
  width: 100%;
  height: 700px;
  border: 1px solid #ddd;
}
.other-header {
  display: flex;
  align-items: center;
}
.list-item {
  border-radius: 5px;
  padding: 10px;
  border: 1px solid #ddd;
  background: #fff;
  margin-bottom: 10px;
  min-width: 400px;
  cursor: move;
}
.ghost {
  opacity: 0.5;
  background: #c8ebfb;
}
.list-container {
  display: flex;
}
.list-container .list-item {
  margin-right: 10px;
}
.group .list-item {
  background: rgb(241, 148, 114);
  color: #fff;
}
</style>>
