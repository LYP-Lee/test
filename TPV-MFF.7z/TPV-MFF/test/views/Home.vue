<template>
  <div class="wrapper">
    <div class="content">
      <div class="base">
        <div class="base-item">
          <div class="base-item-box">
            <div class="base-icon-box base-icon-box-add">
              <Common-icon icon="md-person-add" color="#fff" :size="36"></Common-icon>
            </div>
            <div class="base-content">
              <div class="base-content-data">803</div>
              <div class="base-content-label">新增用户</div>
            </div>
          </div>
        </div>
        <div class="base-item">
          <div class="base-item-box">
            <div class="base-icon-box base-icon-box-locate">
              <Common-icon icon="md-locate" color="#fff" :size="36"></Common-icon>
            </div>
            <div class="base-content">
              <div class="base-content-data">232</div>
              <div class="base-content-label">累计点击</div>
            </div>
          </div>
        </div>
        <div class="base-item">
          <div class="base-item-box">
            <div class="base-icon-box base-icon-box-help">
              <Common-icon icon="md-help-circle" color="#fff" :size="36"></Common-icon>
            </div>
            <div class="base-content">
              <div class="base-content-data">142</div>
              <div class="base-content-label">新增问答</div>
            </div>
          </div>
        </div>
        <div class="base-item">
          <div class="base-item-box">
            <div class="base-icon-box base-icon-box-share">
              <Common-icon icon="md-share" color="#fff" :size="36"></Common-icon>
            </div>
            <div class="base-content">
              <div class="base-content-data">657</div>
              <div class="base-content-label">分享统计</div>
            </div>
          </div>
        </div>
        <div class="base-item">
          <div class="base-item-box">
            <div class="base-icon-box base-icon-box-chatbubbles">
              <Common-icon icon="md-chatbubbles" color="#fff" :size="36"></Common-icon>
            </div>
            <div class="base-content">
              <div class="base-content-data">12</div>
              <div class="base-content-label">新增互动</div>
            </div>
          </div>
        </div>
        <div class="base-item">
          <div class="base-item-box">
            <div class="base-icon-box base-icon-box-map">
              <Common-icon icon="md-map" color="#fff" :size="36"></Common-icon>
            </div>
            <div class="base-content">
              <div class="base-content-data">14</div>
              <div class="base-content-label">新增页面</div>
            </div>
          </div>
        </div>
      </div>
      <div class="chart">
        <div class="chart-item chart-item-pie">
          <div class="chart-item-box chart-item-box-pie">
            <div class="chart-item-box-content" ref="pie"></div>
          </div>
        </div>
        <div class="chart-item chart-item-histogram">
          <div class="chart-item-box chart-item-box-histogram">
            <div class="chart-item-box-content" ref="histogram"></div>
          </div>
        </div>
        <div class="chart-item chart-item-line">
          <div class="chart-item-box chart-item-box-line">
            <div class="chart-item-box-content" ref="line"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import CommonIcon from '@/components/commonIcon'
import echarts from 'echarts'
export default {
  name: 'home',
  components: {
    CommonIcon
  },
  props: {},
  data () {
    return {
      pieDom: null,
      histogramDom: null,
      lineDom: null,
      pieOption: {
        title: {
          text: '用户访问来源',
          subtext: '',
          x: 'center'
        },
        tooltip: {
          trigger: 'item',
          formatter: '{a} <br/>{b} : {c} ({d}%)'
        },
        legend: {
          orient: 'vertical',
          left: 'left',
          data: [
            { name: '直接访问' },
            { name: '邮件营销' },
            { name: '联盟广告' },
            { name: '视频广告' },
            { name: '搜索引擎' }
          ]
        },
        series: [
          {
            type: 'pie',
            radius: '55%',
            center: ['50%', '60%'],
            data: [
              { value: 335, name: '直接访问' },
              { value: 310, name: '邮件营销' },
              { value: 234, name: '联盟广告' },
              { value: 135, name: '视频广告' },
              { value: 1548, name: '搜索引擎' }
            ],
            itemStyle: {
              emphasis: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
            }
          }
        ]
      },
      histogramOption: {
        title: {
          text: '每周用户活跃量',
          subtext: '',
          x: 'center'
        },
        xAxis: {
          type: 'category',
          data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
        },
        yAxis: {
          type: 'value'
        },
        series: [{
          data: [13253, 34235, 26321, 12340, 24643, 1322, 1324],
          type: 'bar',
          itemStyle: {
            color: new echarts.graphic.LinearGradient(
              0, 0, 0, 1,
              [
                { offset: 0, color: '#83bff6' },
                { offset: 0.5, color: '#188df0' },
                { offset: 1, color: '#188df0' }
              ]
            )
          }
        }]
      },
      lineOption: {
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            label: {
              backgroundColor: '#6a7985'
            }
          }
        },
        grid: {
          top: '3%',
          left: '1.2%',
          right: '1%',
          bottom: '3%',
          containLabel: true
        },
        xAxis: [
          {
            type: 'category',
            boundaryGap: false,
            data: ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
          }
        ],
        yAxis: [
          {
            type: 'value'
          }
        ],
        series: [
          {
            name: '运营商/网络服务',
            type: 'line',
            stack: '总量',
            areaStyle: {
              normal: {
                color: '#2d8cf0'
              }
            },
            data: [120, 132, 101, 134, 90, 230, 210]
          },
          {
            name: '银行/证券',
            type: 'line',
            stack: '总量',
            areaStyle: {
              normal: {
                color: '#10A6FF'
              }
            },
            data: [257, 358, 278, 234, 290, 330, 310]
          },
          {
            name: '游戏/视频',
            type: 'line',
            stack: '总量',
            areaStyle: {
              normal: {
                color: '#0C17A6'
              }
            },
            data: [379, 268, 354, 269, 310, 478, 358]
          },
          {
            name: '餐饮/外卖',
            type: 'line',
            stack: '总量',
            areaStyle: {
              normal: {
                color: '#4608A6'
              }
            },
            data: [320, 332, 301, 334, 390, 330, 320]
          },
          {
            name: '快递/电商',
            type: 'line',
            stack: '总量',
            label: {
              normal: {
                show: true,
                position: 'top'
              }
            },
            areaStyle: {
              normal: {
                color: '#398DBF'
              }
            },
            data: [820, 645, 546, 745, 872, 624, 258]
          }
        ]
      }
    }
  },
  created () { },
  mounted () {
    this.$nextTick(() => {
      this.init()
    })
  },
  updated () { },
  destroyed () { },
  methods: {
    init () {
      this.iniPie()
      this.initHistogram()
      this.initLine()
      this.initEvent()
    },
    initEvent () {
      window.addEventListener('resize', () => {
        this.$nextTick(() => {
          this.pieDom.resize()
          this.histogramDom.resize()
          this.lineDom.resize()
        })
      })
    },
    iniPie () {
      this.pieDom = echarts.init(this.$refs.pie);
      this.pieDom.setOption(this.pieOption);
    },
    initHistogram () {
      this.histogramDom = echarts.init(this.$refs.histogram);
      this.histogramDom.setOption(this.histogramOption);
    },
    initLine () {
      this.lineDom = echarts.init(this.$refs.line);
      this.lineDom.setOption(this.lineOption);
    }
  },
  computed: {},
  watch: {}
}
</script>
<style lang="less" scoped>
.content {
  padding: 10px;
  .base {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    justify-content: space-between;
  }
  .base-item {
    margin: 0 10px 20px;
    flex: 1;
  }
  .base-item-box {
    display: flex;
    align-items: center;
    width: 100%;
    height: 110px;
    border-radius: 4px;
    background: #fff;
    box-sizing: border-box;
    overflow: hidden;
  }
  .base-icon-box {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100%;
    width: 90px;
    &.base-icon-box-add {
      background: rgb(45, 140, 240);
    }
    &.base-icon-box-locate {
      background: rgb(25, 190, 107);
    }
    &.base-icon-box-help {
      background: rgb(255, 153, 0);
    }
    &.base-icon-box-share {
      background: rgb(237, 63, 20);
    }
    &.base-icon-box-chatbubbles {
      background: rgb(228, 108, 187);
    }
    &.base-icon-box-map {
      background: rgb(154, 102, 228);
    }
  }
  .base-content {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    min-width: 120px;
    height: 100%;
    text-align: center;
    color: #515a6e;
  }
  .base-content-data {
    font-size: 50px;
    line-height: 75px;
  }
  .base-content-label {
    font-size: 14px;
  }
  .chart {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
  }
  .chart-item {
    padding: 0 10px 20px;
    &.chart-item-pie {
      flex: 4;
    }
    &.chart-item-histogram {
      flex: 6;
    }
    &.chart-item-line {
      width: 100%;
      padding-bottom: 0;
    }
  }
  .chart-item-box {
    width: 100%;
    height: 340px;
    background: #fff;
    border-radius: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    padding: 10px;
    box-sizing: border-box;
    &.chart-item-box-pie {
      min-width: 400px;
    }
    &.chart-item-box-histogram {
      min-width: 600px;
    }
  }
  .chart-item-box-content {
    width: 100%;
    height: 100%;
  }
  @media (min-width: 1200px) {
    .chart-item {
      overflow: hidden;
    }
  }
}
</style>
