<template>
  <div class="select-wrapper">
    <div class="header">
      <h1>vue-treeselect下拉选择组件</h1>
    </div>
    <div class="content">
      <div class="content-item">
        <h2>使用示例（展示典型，具体查看文档）</h2>
        <p>
          <span>示例一（基础，可通过输入模糊匹配、单选选）</span>
          <treeselect v-model="value" :options="options" placeholder="Select your favourite(s)..." />
        </p>
        <p>
          <span>示例二（多选,:multiple="true"）</span>
          <treeselect
            v-model="value2"
            :multiple="true"
            :options="options"
            placeholder="Select your favourite(s)..."
          />
        </p>
        <p>
          <span>示例三(异步加载，:load-options，children:null)</span>
          <treeselect
            v-model="value3"
            :multiple="true"
            :options="options3"
            :load-options="loadOptions"
            placeholder="Select your favourite(s)..."
          />
        </p>
        <p>
          <span>示例四(异步搜索，:async="true")</span>
          <treeselect v-model="value4" :multiple="true" :async="true" :load-options="loadOptions4" />
        </p>
        <p>
          <span>示例五(单独选，不会选择父节点连同子节点，:flat="true"属性)</span>
          <treeselect :multiple="true" :options="options" :flat="true" />
        </p>
        <p>
          <span>示例六(筛选选项)</span>
          <treeselect :multiple="true" :options="options" :value-consists-of="valueConsistsOf" />
        </p>
        <p>
          <span style="color:orangered">更多</span>
          <br />还有一些自定义、禁用、效果展示、功能开关等功能，详细请查阅文档
        </p>
      </div>
      <div class="content-item">
        <h2>github地址</h2>
        <p>
          <a
            href="https://github.com/riophae/vue-treeselect"
            target="parent"
          >https://github.com/riophae/vue-treeselect</a>
        </p>
      </div>
      <div class="content-item">
        <h2>文档地址</h2>
        <p>
          <a href="https://vue-treeselect.js.org/" target="parent">https://vue-treeselect.js.org/</a>
        </p>
      </div>
      <div class="content-item">
        <h2>注意</h2>
        <p>协议：MIT Licence.</p>
      </div>
    </div>
  </div>
</template>
<script>
// import the component
import Treeselect from '@riophae/vue-treeselect'
// import the styles
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
import { LOAD_CHILDREN_OPTIONS, ASYNC_SEARCH } from '@riophae/vue-treeselect'

// We just use `setTimeout()` here to simulate an async operation
// instead of requesting a real API server for demo purpose.
const simulateAsyncOperation = fn => {
  setTimeout(fn, 2000)
}
export default {
  name: 'treeSelectPage',
  data () {
    return {
      // define the default value
      value: null,
      value2: null,
      value3: null,
      value4: null,
      // define options
      options: [{
        id: 'a',
        label: 'a',
        children: [{
          id: 'aa',
          label: 'aa',
        }, {
          id: 'ab',
          label: 'ab',
        }],
      }, {
        id: 'b',
        label: 'b',
      }, {
        id: 'c',
        label: 'c',
      }],
      options3: [{
        id: 'success',
        label: 'With children',
        // Declare an unloaded branch node.
        children: null,
      }, {
        id: 'no-children',
        label: 'With no children',
        children: null,
      }, {
        id: 'failure',
        label: 'Demonstrates error handling',
        children: null,
      }],
      //"ALL"-选中的所有节点都将包含在value数组中
      //"BRANCH_PRIORITY"（默认）-如果选中了分支节点，则其所有后代将被排除在value数组之外
      //"LEAF_PRIORITY"-如果选中了分支节点，则此节点本身及其分支后代将从value阵列中排除，但其叶后代将包括在内
      //"ALL_WITH_INDETERMINATE"-选中的所有节点将包括在value数组中，另外还有不确定的节点
      valueConsistsOf: 'LEAF_PRIORITY'
    }
  },
  components: {
    Treeselect
  },
  computed: {
  },
  methods: {
    loadOptions ({ action, parentNode, callback }) {
      // Typically, do the AJAX stuff here.
      // Once the server has responded,
      // assign children options to the parent node & call the callback.

      if (action === LOAD_CHILDREN_OPTIONS) {
        switch (parentNode.id) {
          case 'success': {
            simulateAsyncOperation(() => {
              parentNode.children = [{
                id: 'child',
                label: 'Child option',
              }]
              callback()
            })
            break
          }
          case 'no-children': {
            simulateAsyncOperation(() => {
              parentNode.children = []
              callback()
            })
            break
          }
          case 'failure': {
            simulateAsyncOperation(() => {
              callback(new Error('Failed to load options: network error.'))
            })
            break
          }
          default: /* empty */
        }
      }
    },
    loadOptions4 ({ action, searchQuery, callback }) {
      if (action === ASYNC_SEARCH) {
        simulateAsyncOperation(() => {
          const options = [1, 2, 3, 4, 5].map(i => ({
            id: `${searchQuery}-${i}`,
            label: `${searchQuery}-${i}`,
          }))
          callback(null, options)
        })
      }
    }
  },
  watch: {
  },
  created () {

  },
  mounted () {
  }
}
</script>
<style lang='less' scoped>
.content-item {
  text-align: left;
  padding: 20px;
  p {
    padding-top: 10px;
  }
}
</style>>
