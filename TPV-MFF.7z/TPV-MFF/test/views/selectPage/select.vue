<template>
  <div class="select-wrapper">
    <div class="header">
      <h1>vue-select下拉选择组件</h1>
    </div>
    <div class="content">
      <div class="content-item">
        <h2>使用示例</h2>
        <p>
          <span>示例一</span>
          <v-select :options="options"></v-select>
        </p>
        <p>
          <span>示例二</span>（多选）
          <v-select multiple v-model="selected" :options="['Canada','United States']" />
          值：{{selected}}
        </p>
        <p>
          <span>示例三</span>(默认显示labe的值)
          <v-select v-model="selected2" :options="[{label: 'Canada', code: 'ca'}]" />
          值：{{selected2}}
        </p>
        <p>
          <span>示例四</span>(显示指定labe的值)
          <v-select
            v-model="selected3"
            label="countryName"
            :options="[{countryCode: 'CA',countryName: 'Canada'}]"
          />
          值：{{selected3}}
        </p>
        <p>
          <span>示例五</span>（taggable属性为可以选择不存在的输入）
          <v-select taggable multiple />
        </p>
        <p>
          <span>示例六</span>（push-tags属性为可以将输入推到选项中）
          <v-select taggable multiple push-tags />
        </p>
        <p>
          <span>示例七</span>(自定义样式)
          <v-select :options="options2" label="title">
            <template slot="option" slot-scope="option">
              <Icon :type="option.icon" />
              {{ option.title }}
            </template>
          </v-select>
        </p>
      </div>
      <div class="content-item">
        <h2>github地址</h2>
        <p>
          <a
            href="https://github.com/sagalbot/vue-select"
            target="parent"
          >https://github.com/sagalbot/vue-select</a>
        </p>
      </div>
      <div class="content-item">
        <h2>文档地址</h2>
        <p>
          <a href="https://vue-select.org/" target="parent">https://vue-select.org/</a>
        </p>
      </div>
      <div class="content-item">
        <h2>注意</h2>
        <p>协议：MIT Licence.</p>
      </div>
    </div>
  </div>
</template>
<script>
import vSelect from "vue-select";
import 'vue-select/dist/vue-select.css';
export default {
  name: 'vueSelectPage',
  data () {
    return {
      options: [
        'foo',
        'bar',
        'baz'
      ],
      options2: [
        {
          title: 'Read the Docs',
          icon: 'md-baseball',
          url: 'https://codeclimate.com/github/sagalbot/vue-select'
        },
        {
          title: 'View on GitHub',
          icon: 'md-battery-charging',
          url: 'https://codeclimate.com/github/sagalbot/vue-select'
        },
        {
          title: 'View on NPM',
          icon: 'ios-boat',
          url: 'https://codeclimate.com/github/sagalbot/vue-select'
        },
        {
          title: 'View Codepen Examples',
          icon: 'md-bicycle',
          url: 'https://codeclimate.com/github/sagalbot/vue-select'
        }
      ],
      selected: [],
      selected2: [],
      selected3: []
    }
  },
  components: {
    vSelect
  },
  computed: {
  },
  methods: {
    onEditorBlur () {

    },
    onEditorFocus () {

    },
    onEditorReady () {

    }
  },
  watch: {
  },
  created () {

  },
  mounted () {
  }
}
</script>
<style lang='less' scoped>
.content-item {
  text-align: left;
  padding: 20px;
  p {
    padding-top: 10px;
  }
}
</style>>
