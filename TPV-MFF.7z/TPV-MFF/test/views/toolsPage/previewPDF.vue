<template>
  <div class="theme-wrapper">
    <div class="header">
      <h1>预览pdf组件</h1>
    </div>
    <div class="content">
      <div class="content-item">
        <h2>使用方法</h2>
        <p>import PDF from '@/components/pdf'引入组件，注册并使用</p>
        <p>属性url为文件地址,文件不能跨域访问</p>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'pdfPage',
  data () {
    return {}
  },
  components: {
  },
  computed: {

  },
  methods: {

  },
  created () {

  },
  mounted () {

  }
}
</script>
<style lang='less' scoped>
.content-item {
  text-align: left;
  padding: 20px;
  p {
    padding-top: 10px;
  }
}
</style>>
