<template>
  <div class="theme-wrapper">
    <div class="header">
      <h1>刷新组件</h1>
    </div>
    <div class="content">
      <div class="content-item">
        <h2>使用方法</h2>
        <p>import Reload from '@/components/reload'引入组件，注册并使用</p>
        <p>重新加载当前页面</p>
      </div>
      <div class="content-item">
        <h2>使用示例</h2>
        <p>
          <Reload></Reload>
        </p>
      </div>
    </div>
  </div>
</template>
<script>
import Reload from '@/components/reload'
export default {
  name: 'reloadPage',
  data () {
    return {}
  },
  components: {
    Reload
  },
  computed: {

  },
  methods: {

  },
  created () {
    console.log('重新加载页面！')
    alert('重新加载了！');
  },
  mounted () {

  }
}
</script>
<style lang='less' scoped>
.content-item {
  text-align: left;
  padding: 20px;
  p {
    padding-top: 10px;
  }
}
</style>>
