<template>
  <div class="theme-wrapper">
    <div class="header">
      <h1>图标组件</h1>
    </div>
    <div class="content">
      <div class="content-item">
        <h2>图标组件使用方法</h2>
        <p>import CommonIcon from '@/components/commonIcon'引入组件，注册并使用</p>
        <p>可传入三个属性值icon,size,color</p>
        <p>icon可为iview的图标、字体图标、图片的地址</p>
        <p>size不传默认为18px</p>
        <p>color不传默认为iview的颜色</p>
      </div>
      <div class="content-item">
        <h2>注意</h2>
        <p style="color:orangered">icon传入图片，如果是本地图片，可使用require引入（`${require('路径')}`）</p>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'commonIcon',
  data () {
    return {}
  },
  computed: {

  },
  methods: {

  },
  created () {

  },
  mounted () {

  }
}
</script>
<style lang='less' scoped>
.content-item{
  text-align: left;
  padding: 20px;
  p{
    padding-top: 10px;
  }
}
</style>>
