<template>
  <div class="theme-wrapper">
    <div class="header">
      <h1>侧边菜单组件</h1>
    </div>
    <div class="content">
      <div class="content-item">
        <h2>使用说明</h2>
        <p>import SiderMenu from '@/components/layout/siderMenu'引入组件，注册并使用</p>
        <p>
        <pre>可传入属性值
        theme: {// dark/light
          type: String,
          default: 'dark'
        },
        activeName: {//选中项
          type: String
        },
        openedNames: {//打开项
          type: Array,
          default: () => []
        },
        menuList: {
          type: Array,
          default: () => []
        },
        collapsed: {
          type: Boolean,
          default: false
        }</pre>
        </p>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'siderMenu',
  data () {
    return {}
  },
  computed: {

  },
  methods: {

  },
  created () {

  },
  mounted () {

  }
}
</script>
<style lang='less' scoped>
.content-item{
  text-align: left;
  padding: 20px;
  p{
    padding-top: 10px;
  }
}
</style>>
