<template>
  <div class="theme-wrapper">
    <div class="header">
      <h1>语言组件</h1>
    </div>
    <div class="content">
      <div class="content-item">
        <h2>语言组件使用方法</h2>
        <p>import Language from '@/components/layout/language'引入组件，注册并使用</p>
        <p>在lang文件下zh.js,en.js,zh-TW.js文件里面配置对应的语言提示及字段</p>
        <p>使用$t('')语法</p>
      </div>
      <div class="content-item">
        <h2>注意</h2>
        <p style="color:orangered">配置路由时需要配置对应的语言，name对应meta.title</p>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'language',
  data () {
    return {}
  },
  computed: {

  },
  methods: {

  },
  created () {

  },
  mounted () {

  }
}
</script>
<style lang='less' scoped>
.content-item{
  text-align: left;
  padding: 20px;
  p{
    padding-top: 10px;
  }
}
</style>>
