<template>
  <div class="theme-wrapper">
    <div class="header">
      <h1>面包屑组件</h1>
    </div>
    <div class="content">
      <div class="content-item">
        <h2>使用方法</h2>
        <p>import CustomBreadCrumb from '@/components/layout/customBreadCrumb'引入组件，注册并使用</p>
        <p>可传入list、type两个属性值，若type值不传，则默认根据route展示路由</p>
        <p>若传入type值为custom，则根据传入的list数组值渲染展示</p>
      </div>
      <div class="content-item">
        <h2>注意</h2>
        <p style="color:orangered">type为custom是，list必须为对象数组，对象属性值必须包含name跟icon(标题跟图标)</p>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'breadcrumb',
  data () {
    return {}
  },
  computed: {

  },
  methods: {

  },
  created () {

  },
  mounted () {

  }
}
</script>
<style lang='less' scoped>
.content-item{
  text-align: left;
  padding: 20px;
  p{
    padding-top: 10px;
  }
}
</style>>
