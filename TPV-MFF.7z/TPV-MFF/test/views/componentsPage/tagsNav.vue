<template>
  <div class="theme-wrapper">
    <div class="header">
      <h1>标签导航组件</h1>
    </div>
    <div class="content">
      <div class="content-item">
        <h2>使用方法</h2>
        <p>import CustomTagsNav from '@/components/layout/tagsNav/customTagsNav'引入组件，注册并使用</p>
        <p>传入属性：
          <pre>
    list: {
      type: Array,
      default () {
        return []
      }
    }
          </pre>
        </p>
      </div>
      <div class="content-item">
        <h2>注意</h2>
        <p style="color:orangered">list属性值包含 name(唯一)，meta:{title}：显示标题，isClosable：当前标签是否有关闭按钮，active:是否是激活</p>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'tagsNav',
  data () {
    return {}
  },
  computed: {

  },
  methods: {

  },
  created () {

  },
  mounted () {

  }
}
</script>
<style lang='less' scoped>
.content-item{
  text-align: left;
  padding: 20px;
  p{
    padding-top: 10px;
  }
}
</style>>
