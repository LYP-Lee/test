import util from '@/libs/util'
import routers from '@/router/routers'
export default {
  state: {
    routers: routers,
    currentRoute: {},
    tagsNavList: [],
    isRouteActive: true
  },
  getters: {
    menuList: (state, getters, rootState) => util.getMenuByRouter(state.routers, rootState.user.access),
    allPageList: (state, getters, rootState) => util.getPagesByRouter(state.routers),
    cacheList: (state, getters, rootState) => util.getPageNameByList(util.getCacheStatusPageByList(getters.allPageList, true)),
    notCacheListByRoute: (state, getters, rootState) => util.getPageNameByList(util.getCacheStatusPageByList(getters.allPageList, false)),
    notCacheList: (state, getters, rootState, data) => {
      if (state.isRouteActive) {
        return getters.notCacheListByRoute
      } else {
        let notCacheList = JSON.parse(JSON.stringify(getters.notCacheListByRoute))
        notCacheList.push(state.currentRoute.name)
        return notCacheList
      }
    }
  },
  mutations: {
    setRouters (state, routers) {
      state.routers = routers
    },
    setTagsNavList (state, list) {
      state.tagsNavList = list
    },
    setIsRouteActive (state, flag) {
      state.isRouteActive = flag
    },
    setCurrentRoute (state, route) {
      state.currentRoute = route
    }
  },
  actions: {
    setRouters ({ commit }, data) {
      commit('setRouters', data)
    },
    setTagsNavList ({ commit }, data) {
      commit('setTagsNavList', data)
    },
    setIsRouteActive ({ commit }, data) {
      commit('setIsRouteActive', data)
    },
    setCurrentRoute ({ commit }, data) {
      commit('setCurrentRoute', data)
    }
  }
}
