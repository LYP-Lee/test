<template>
  <div class="move-wrapper">
    <div
      class="move-box"
      :class="{'move-transition':transitionFlag}"
      :style="style"
      @mousedown="moveStart($event)"
      @mouseup="moveEnd($event)"
      ref="move"
    >
      <div class="move-header">
        <div class="move-back" @click="back($event)" :title="$t('common.backToOriginalPlace')">
          <CommonIcon icon="ios-funnel-outline" :size="26" color="#fff"></CommonIcon>
        </div>
      </div>
      <div class="move-content">
        <slot></slot>
      </div>
    </div>
    <div class="move-bg" ref="base">
      <div class="move-mask"></div>
      <slot></slot>
    </div>
  </div>
</template>

<script>
import CommonIcon from '@/components/commonIcon'
export default {
  name: 'move',
  components: {
    CommonIcon
  },
  props: {
  },
  data () {
    return {
      transitionFlag: false,
      isMove: false,
      startLeft: 0,
      startTop: 0,
      currentLeft: 0,
      currentTop: 0,
      mouseStartX: 0,
      mouseStartY: 0,
      style: ''
    }
  },
  created () {
  },
  mounted () {
    this.init()
  },
  updated () { },
  destroyed () { },
  methods: {
    init () {
      this.startLeft = this.$refs.move.getBoundingClientRect().left
      this.startTop = this.$refs.move.getBoundingClientRect().top
      this.initEvent()
    },
    initEvent () {
      document.addEventListener('mousemove', this.move)
    },
    moveStart (e) {
      this.currentLeft = this.$refs.move.getBoundingClientRect().left
      this.currentTop = this.$refs.move.getBoundingClientRect().top
      this.style = `position:fixed;left:${this.currentLeft}px;top:${this.currentTop}px;z-index:1111`
      this.isMove = true
      this.mouseStartX = e.clientX
      this.mouseStartY = e.clientY
    },
    move (e) {
      if (!this.isMove) {
        return
      }
      let x = e.clientX - this.mouseStartX
      let y = e.clientY - this.mouseStartY
      this.style = `position:fixed;left:${this.currentLeft + x}px;top:${this.currentTop + y}px;z-index:1111`
    },
    moveEnd (e) {
      this.isMove = false
    },
    back (e) {
      e.stopPropagation();
      this.isMove = false
      this.transitionFlag = true
      let left = this.$refs.base.getBoundingClientRect().left
      let top = this.$refs.base.getBoundingClientRect().top
      this.style = `position:fixed;left:${left}px;top:${top}px;z-index:1111`
      setTimeout(() => {
        this.transitionFlag = false
        this.style = `position:absolute;left:0;top:0`
      }, 600)
    }
  },
  computed: {

  },
  watch: {}
}
</script>
<style lang="less" scoped>
.move-wrapper {
  position: relative;
  .move-bg {
    position: relative;
    opacity: 0;
  }
  .move-mask {
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    z-index: 1111;
  }
}
.move-box {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 11;
  cursor: move;
  user-select: none;
  &.move-transition {
    transition: all 0.6s;
  }
  &:hover {
    .move-header {
      display: flex;
    }
  }
  .move-header {
    display: none;
    position: absolute;
    top: -40px;
    left: 0;
    width: 100%;
    align-items: center;
    justify-content: flex-end;
    height: 40px;
    background: rgba(0, 0, 0, 0.1);
    border-radius: 4px;
    padding: 0 10px;
  }
  .move-back {
    cursor: pointer;
  }
}
</style>
