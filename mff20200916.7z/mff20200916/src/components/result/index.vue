<template>
  <div class="result-container">
    <div class="result-main">
      <div class="icon-box">
        <Common-icon icon="ios-checkmark-circle" :size="82" color="#19be6b" v-if="type=='success'"></Common-icon>
        <Common-icon icon="ios-close-circle" :size="82" color="#ed4014" v-else></Common-icon>
      </div>
      <div class="title" v-if="type=='success'">{{ $t('common.successResult') }}</div>
      <div class="title" v-else>{{ $t('common.failureResult') }}</div>
      <div class="tip-box" v-if="tip">{{ tip }}</div>
      <div class="tip-content" v-if="tipContent">{{ tipContent }}</div>
      <div class="content">
        <slot name="content"></slot>
      </div>
      <div class="button-box">
        <Button type="primary" @click="back()">{{ $t('common.back') }}</Button>
        <slot name="button"></slot>
      </div>
    </div>
  </div>
</template>

<script>
import CommonIcon from '@/components/commonIcon'
export default {
  name: 'success',
  components: {
    CommonIcon
  },
  props: {
    type: {
      type: String,
      default: 'success'
    },
    tip: {
      type: String
    },
    tipContent: {
      type: String
    }
  },
  data () {
    return {
    }
  },
  created () {
  },
  mounted () {
  },
  updated () { },
  destroyed () { },
  methods: {
    back () {
      this.$router.go(-1)
    }
  },
  computed: {

  },
  watch: {}
}
</script>
<style lang="less" scoped>
.result-container {
  position: relative;
  padding: 16px 16px 40px;
  background: #fff;
  margin: 16px;
  border-radius: 5px;
}
.result-main {
  width: 72%;
  margin: 0 auto;
}
.icon-box {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 16px 0 24px;
}
.title {
  font-size: 24px;
  text-align: center;
  color: #17233d;
  padding-bottom: 16px;
}
.tip-box {
  font-size: 14px;
  color: #808695;
  padding-bottom: 16px;
  text-align: center;
}
.tip-content {
  font-size: 14px;
  color: #515a6e;
  padding: 24px 40px;
  text-align: left;
  background: #f8f8f9;
  border-radius: 4px;
  margin-bottom: 16px;
}
.button-box {
  display: flex;
  align-items: center;
  justify-content: center;
  padding-top: 16px;
  button {
    margin: 0 10px;
  }
}
</style>
