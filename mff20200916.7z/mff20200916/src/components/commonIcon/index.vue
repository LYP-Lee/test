<template>
  <div class="icon-wrapper">
    <Icon :type="iconVal" :size="size" :color="color" v-if="type == 'icon'" />
    <Icon :custom="iconVal" :size="size" :color="color" v-if="type == 'other'" />
    <img :src="iconVal" v-if="type == 'image'" :width="`${size}px`" />
  </div>
</template>

<script>
export default {
  name: 'commonIcon',
  components: {
  },
  props: {
    icon: {
      type: String,
      default: ''
    },
    size: {
      type: Number,
      default: 18
    },
    color: {
      type: String,
      default: ''
    }
  },
  data () {
    return {
      type: 'icon',
      iconVal: ''
    }
  },
  created () {
    this.init()
  },
  mounted () {
  },
  updated () { },
  destroyed () { },
  methods: {
    init () {
      this.initType()
    },
    initType () {
      if (this.icon.startsWith('_')) {
        this.iconVal = this.icon.slice(1, this.icon.length)
        this.type = 'other'
      } else if (this.icon.startsWith('image_')) {
        this.iconVal = this.icon.slice(6, this.icon.length)
        this.type = 'image'
      } else {
        this.iconVal = this.icon
      }
    }
  },
  computed: {

  },
  watch: {}
}
</script>
<style lang="less" scoped>
.icon-wrapper {
  display: inline;
  vertical-align: top;
  img {
    font-size: 0;
    vertical-align: text-bottom;
  }
}
.ivu-icon{
  vertical-align: middle;
}
</style>
