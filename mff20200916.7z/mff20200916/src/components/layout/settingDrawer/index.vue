<template>
  <div class="setting-drawer-wrapper">
    <Common-icon icon="md-more" @click.native="isShow = true" :size="26"></Common-icon>
    <Drawer :closable="false" v-model="isShow">
      <div class="drawer-container">
        <div class="drawer-item" v-if="themeFlag">
          <div class="drawer-header"><span>{{ $t('settings.themeSetting') }}</span></div>
          <div class="drawer-content">
            <div class="theme-content">
              <div class="theme-item" @click="setSiderTheme('dark')">
                <Tooltip :content="$t('settings.darkSideSidebar')" placement="top" transfer>
                  <img :src="require('@/assets/images/theme-svg-icon/sider-theme1.svg')"/>
                </Tooltip>
                <div class="theme-dot" :class="{'selected-dot':themeSetting.sider === 'dark'}"></div>
              </div>
              <div class="theme-item" @click="setSiderTheme('bright')">
                <Tooltip :content="$t('settings.brightSideSidebar')" placement="top" transfer>
                  <img :src="require('@/assets/images/theme-svg-icon/sider-theme2.svg')"/>
                </Tooltip>
                <div class="theme-dot" :class="{'selected-dot':themeSetting.sider === 'bright'}"></div>
              </div>
            </div>
            <div class="theme-content">
              <div class="theme-item" @click="setHeaderTheme('bright')">
                <Tooltip :content="$t('settings.brightSideTopbar')" placement="top" transfer>
                  <img :src="require('@/assets/images/theme-svg-icon/header-theme1.svg')"/>
                </Tooltip>
                <div class="theme-dot" :class="{'selected-dot':themeSetting.header === 'bright'}"></div>
              </div>
              <div class="theme-item" @click="setHeaderTheme('dark')">
                <Tooltip :content="$t('settings.darkSideTopbar')" placement="top" transfer>
                  <img :src="require('@/assets/images/theme-svg-icon/header-theme2.svg')"/>
                </Tooltip>
                <div class="theme-dot" :class="{'selected-dot':themeSetting.header === 'dark'}"></div>
              </div>
              <div class="theme-item" @click="setHeaderTheme('main')">
                <Tooltip :content="$t('settings.mainTopbar')" placement="top" transfer>
                  <img :src="require('@/assets/images/theme-svg-icon/header-theme3.svg')"/>
                </Tooltip>
                <div class="theme-dot" :class="{'selected-dot':themeSetting.header === 'main'}"></div>
              </div>
            </div>
          </div>
        </div>
        <div class="drawer-item">
          <div class="drawer-header"><span>{{ $t('settings.navSetting') }}</span></div>
          <div class="drawer-content">
            <div class="switch-item-box">
              <label>{{ $t('settings.collapsedBtn') }}</label>
              <IviewSwitch :value="navSetting.collapsedBtn" @on-change="collapsedBtnStatusChange" />
            </div>
            <div class="switch-item-box">
              <label>{{ $t('settings.breadcrumb') }}</label>
              <IviewSwitch :value="navSetting.breadcrumb" @on-change="breadcrumbStatusChange" />
            </div>
            <div class="switch-item-box">
              <label>{{ $t('settings.fullScreenBtn') }}</label>
              <IviewSwitch :value="navSetting.fullScreen" @on-change="fullScreenStatusChange" />
            </div>
            <div class="switch-item-box">
              <label>{{ $t('settings.language') }}</label>
              <IviewSwitch :value="navSetting.language" @on-change="languageStatusChange" />
            </div>
          </div>
        </div>
        <div class="drawer-item">
          <div class="drawer-header"><span>{{ $t('settings.othersSetting') }}</span></div>
          <div class="drawer-content">
            <div class="switch-item-box">
              <label>{{ $t('settings.openTagsNav') }}</label>
              <IviewSwitch :value="othersSetting.tagsNav" @on-change="tagsNavStatusChange" />
            </div>
          </div>
        </div>
      </div>
    </Drawer>
  </div>
</template>
<script>
import configs from '@/libs/configs.js'
import CommonIcon from '@/components/commonIcon'
export default {
  name: 'settingDrawer',
  components: {
    CommonIcon
  },
  props: {
  },
  data () {
    return {
      isShow: false
    }
  },
  created () {

  },
  mounted () {
  },
  methods: {
    setSiderTheme (type) {
      this.$store.dispatch('setSiderTheme', type)
    },
    setHeaderTheme (type) {
      this.$store.dispatch('setHeaderTheme', type)
    },
    collapsedBtnStatusChange (status) {
      let navData = this.$store.state.setting.nav
      navData['collapsedBtn'] = status
      this.$store.dispatch('setNav', navData)
    },
    breadcrumbStatusChange (status) {
      let navData = this.$store.state.setting.nav
      navData['breadcrumb'] = status
      this.$store.dispatch('setNav', navData)
    },
    fullScreenStatusChange (status) {
      let navData = this.$store.state.setting.nav
      navData['fullScreen'] = status
      this.$store.dispatch('setNav', navData)
    },
    languageStatusChange (status) {
      let navData = this.$store.state.setting.nav
      navData['language'] = status
      this.$store.dispatch('setNav', navData)
    },
    tagsNavStatusChange (status) {
      let othersData = this.$store.state.setting.others
      othersData['tagsNav'] = status
      this.$store.dispatch('setOthers', othersData)
    }
  },
  computed: {
    themeSetting () {
      return this.$store.state.setting.theme
    },
    themeFlag () {
      return configs.theme
    },
    navSetting () {
      return this.$store.state.setting.nav
    },
    othersSetting () {
      return this.$store.state.setting.others
    }
  }
}
</script>
<style lang="less" scoped>
.setting-drawer-wrapper{
  cursor: pointer;
}
.drawer-header{
  font-size: 14px;
  position: relative;
  padding: 8px 0;
  text-align: center;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #17233d;
  span{
    padding: 0 24px;
  }
  &:before{
    display: block;
    content:'';
    height: 1px;
    flex:1;
    background: #e8eaec;
  }
  &:after{
    display: block;
    content: '';
    height: 1px;
    flex: 1;
    background: #e8eaec;
  }
}
.drawer-content{
  padding: 12px 0;
}
.theme-content{
  display: flex;
  align-items: center;
  padding-bottom: 10px;
  .theme-item{
    padding-left: 20px;
    cursor: pointer;
    &:first-child{
      padding-left: 0;
    }
  }
  .selected-dot{
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: #19be6b;
    margin: 0 auto 10px;
  }
  .theme-dot{
    width: 6px;
    height: 6px;
    border-radius: 50%;
    margin: 0 auto 10px;
  }
}
.switch-item-box{
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 0 20px;
}
</style>
