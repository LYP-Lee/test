<template>
  <div class="breadcrumb-wrapper" v-if="breadcrumbList.length > 0 && breadcrumbList[0].path !== '/home'">
    <Breadcrumb>
      <BreadcrumbItem :to="item.path" v-for="(item,index) in breadcrumbList" :key="index" @click.native="handleClick(item)">
        <span class="breadcrumb-item">
          <Common-icon :icon="item.icon" :key="item.name"></Common-icon>
          {{ item.name }}
        </span>
      </BreadcrumbItem>
    </Breadcrumb>
  </div>
</template>

<script>
import CommonIcon from '@/components/commonIcon'
export default {
  name: 'customBreadCrumb',
  components: {
    CommonIcon
  },
  props: {
    list: {
      type: Array,
      default () {
        return []
      }
    },
    type: {
      type: String,
      default: 'route'
    } // route/custom 通过路由或是自定义
  },
  data () {
    return {

    }
  },
  created () {
  },
  mounted () { },
  updated () { },
  destroyed () { },
  methods: {
    getBreadCrumbListByRouter () {
      let currentMatched = this.$route.matched
      let arr = []
      for (let i = 0; i < currentMatched.length; i++) {
        if (!currentMatched[i].meta['hideInBread'] || !currentMatched[i]['meta']) {
          let obj = {
            name: this.$t(`router.${currentMatched[i].name}`) || '',
            path: '',
            icon: currentMatched[i].meta.icon
          }
          if (i === currentMatched.length - 1) {
            obj['path'] = currentMatched[i].path
          }
          arr.push(obj)
        }
      }
      return arr
    },
    handleClick (item) {
      this.$emit('breadcrumbItemClick', item)
    }
  },
  computed: {
    breadcrumbList () {
      let listData = []
      if (this.type === 'route') {
        listData = this.getBreadCrumbListByRouter()
      }
      if (this.type === 'custom') {
        listData = this.list
      }
      return listData
    }
  },
  watch: {}
}
</script>
<style lang="less" scoped>
</style>
