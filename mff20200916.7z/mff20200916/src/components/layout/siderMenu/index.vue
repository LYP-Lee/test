<template>
  <div class="sider-menu-wrapper">
    <slot></slot>
    <div class="menu-container">
      <Menu
        ref="menu"
        :theme="theme"
        :active-name="activeName"
        :open-names="currentOpened"
        width="auto"
        accordion
        @on-select="handleSelect"
        v-if="!collapsed"
      >
        <template v-for="(item,index) in menuList">
          <template v-if="item.children && item.children.length > 0">
            <template v-if="(item.meta && item.meta.title) || item.children.length > 1">
              <Sider-menu-item :itemData="item" :key="`${item.name}_${index}`"></Sider-menu-item>
            </template>
            <template v-else>
              <MenuItem :name="item.children[0].name" :key="`${item.children[0].name}_${index}`">
                <Common-icon :icon="item.children[0].meta.icon"></Common-icon>
                {{ $t(`router.${item.children[0].name}`) }}
              </MenuItem>
            </template>
          </template>
          <template v-else>
            <MenuItem :name="item.name" :key="`${item.name}_${index}`">
              <Common-icon :icon="item.meta.icon"></Common-icon>
              {{ $t(`router.${item.name}`) }}
            </MenuItem>
          </template>
        </template>
      </Menu>
      <div class="collapsed-menu" v-if="collapsed">
        <Collapsed-menu :menuList="menuList" @handleSelect="handleSelect"></Collapsed-menu>
      </div>
    </div>
  </div>
</template>

<script>
import SiderMenuItem from './components/siderMenuItem'
import CollapsedMenu from './components/collapsedMenu'
import CommonIcon from '@/components/commonIcon'
export default {
  name: 'siderMenu',
  components: {
    SiderMenuItem,
    CollapsedMenu,
    CommonIcon
  },
  props: {
    theme: {// dark/light
      type: String,
      default: 'dark'
    },
    activeName: {
      type: String
    },
    openedNames: {
      type: Array,
      default: () => []
    },
    menuList: {
      type: Array,
      default: () => []
    },
    collapsed: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      currentOpened: []
    }
  },
  created () {
    this.initOpenedNames()
  },
  mounted () {
  },
  updated () { },
  destroyed () { },
  methods: {
    initOpenedNames () {
      this.currentOpened = JSON.parse(JSON.stringify(this.openedNames))
      if (this.currentOpened.length === 0 && this.menuList.length > 0 && this.activeName) {
        let currentMatched = this.$route.matched
        for (let i = 0; i < currentMatched.length; i++) {
          this.currentOpened.push(currentMatched[i].name)
        }
      }
    },
    handleSelect (name) {
      this.toPage(name)
    },
    toPage (name) {
      if (name !== this.$route.name) {
        this.$router.push({
          name
        })
      }
    }
  },
  computed: {

  },
  watch: {
    openedNames (val) {
      this.currentOpened = val
      this.$nextTick(() => {
        this.$refs.menu.updateOpened()
      })
    }
  }
}
</script>
<style lang="less" scoped>
.sider-menu-wrapper {
  text-align: left;
  user-select: none;
}
/deep/.ivu-menu {
  z-index: 1;
}
</style>
