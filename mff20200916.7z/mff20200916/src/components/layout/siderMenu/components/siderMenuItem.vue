<template>
    <Submenu :name="itemData.name">
        <template slot="title">
            <Common-icon :icon="itemData.meta.icon"></Common-icon>
            <span> {{ $t(`router.${itemData.name}`) }}</span>
        </template>
        <template v-for="(item,index) in itemData.children">
            <template v-if="item.children && item.children.length > 0">
                <siderMenuItem :itemData="item" :key="`${item.name}_${index}`"></siderMenuItem>
            </template>
            <template v-else>
                <MenuItem :name="item.name" :key="`${item.name}_${index}`"><Common-icon :icon="item.meta.icon"></Common-icon> {{ $t(`router.${item.name}`) }}</MenuItem>
            </template>
        </template>
    </Submenu>
</template>

<script>
import CommonIcon from '@/components/commonIcon'
export default {
  name: 'siderMenuItem',
  components: {
    CommonIcon
  },
  props: {
    itemData: {
      type: Object
    }
  },
  data () {
    return {

    }
  },
  created () {},
  mounted () {

  },
  updated () {},
  destroyed () {},
  methods: {
  },
  computed: {
  },
  watch: {}
}
</script>
<style lang="less" scoped>

</style>
