<template>
  <div class="collapsed-menu-wrapper">
    <template v-for="item in menuList">
      <div class="menu-item" :key="item.name" v-if="item.children && item.children.length > 1">
        <Collapsed-menu-item :itemData="item" @handleSelect="handleSelect"></Collapsed-menu-item>
      </div>
      <template v-else>
        <Tooltip
          :content="$t(`router.${item.children[0].name}`)"
          :key="item.name"
          v-if="item.children"
          placement="right"
        >
          <div class="menu-item" @click="handleSelect(item.children[0].name)">
            <Common-icon :icon="item.children[0].meta.icon || 'md-help'" color="#fff" :size="26"></Common-icon>
          </div>
        </Tooltip>
        <Tooltip :content="$t(`router.${item.name}`)" :key="item.name" placement="right" v-else>
          <div class="menu-item" @click="handleSelect(item.name)">
            <Common-icon :icon="item.meta.icon || 'md-help'" color="#fff" :size="26"></Common-icon>
          </div>
        </Tooltip>
      </template>
    </template>
  </div>
</template>

<script>
import CommonIcon from '@/components/commonIcon'
import CollapsedMenuItem from './collapsedMenuItem'
export default {
  name: 'collapsedMenu',
  components: {
    CommonIcon,
    CollapsedMenuItem
  },
  props: {
    menuList: {
      type: Array,
      default: () => []
    }
  },
  data () {
    return {

    }
  },
  created () { },
  mounted () {

  },
  updated () { },
  destroyed () { },
  methods: {
    handleSelect (name) {
      this.$emit('handleSelect', name)
    }
  },
  computed: {
  },
  watch: {}
}
</script>
<style lang="less" scoped>
.menu-item {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 60px;
  cursor: pointer;
}
.ivu-tooltip {
  width: 100%;
  .ivu-tooltip-rel {
    width: 100%;
  }
}
</style>
