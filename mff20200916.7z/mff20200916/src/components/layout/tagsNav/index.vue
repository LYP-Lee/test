// 根据路由渲染
<template>
  <div class="tags-nav">
    <div class="close-con">
      <Dropdown transfer @on-click="handleTagsOption" style="margin-top:7px;">
        <Button size="small" type="text">
          <Icon :size="18" type="ios-close-circle-outline" />
        </Button>
        <DropdownMenu slot="list">
          <DropdownItem name="close-all">{{ $t('common.closeAll') }}</DropdownItem>
          <DropdownItem name="close-others">{{ $t('common.closeOthers') }}</DropdownItem>
        </DropdownMenu>
      </Dropdown>
    </div>
    <div class="btn-con left-btn">
      <Button type="text" @click="handleScroll(240)">
        <Icon :size="18" type="ios-arrow-back" />
      </Button>
    </div>
    <div class="btn-con right-btn">
      <Button type="text" @click="handleScroll(-240)">
        <Icon :size="18" type="ios-arrow-forward" />
      </Button>
    </div>
    <div
      class="scroll-outer"
      ref="scrollOuter"
      @DOMMouseScroll="handlescroll"
      @mousewheel="handlescroll"
    >
      <div ref="scrollBody" class="scroll-body" :style="{left: tagBodyLeft + 'px'}">
        <transition-group name="taglist-moving-animation">
          <Tag
            type="dot"
            v-for="(item,index) in list"
            :key="item.name"
            @on-close="handleClose(item,index)"
            @click.native="handleClick(item)"
            :color="$route.name === item.name ? 'primary' : 'default'"
            :closable="item.name !== 'home'"
            style="cursor:pointer"
          >{{ $t(`router.${item.name}`) }}</Tag>
        </transition-group>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'tagsNav',
  props: {
  },
  data () {
    return {
      tagBodyLeft: 0,
      rightOffset: 40,
      outerPadding: 4,
      contextMenuLeft: 0,
      contextMenuTop: 0,
      menuList: {
        others: '关闭其他',
        all: '关闭所有'
      }
    }
  },
  computed: {
    list () {
      return this.$store.state.app.tagsNavList
    }
  },
  created () {
    this.addTagsNavList(this.$route)
  },
  methods: {
    handlescroll (e) {
      var type = e.type
      let delta = 0
      if (type === 'DOMMouseScroll' || type === 'mousewheel') {
        delta = (e.wheelDelta) ? e.wheelDelta : -(e.detail || 0) * 40
      }
      this.handleScroll(delta)
    },
    handleScroll (offset) {
      const outerWidth = this.$refs.scrollOuter.offsetWidth
      const bodyWidth = this.$refs.scrollBody.offsetWidth
      if (offset > 0) {
        this.tagBodyLeft = Math.min(0, this.tagBodyLeft + offset)
      } else {
        if (outerWidth < bodyWidth) {
          if (this.tagBodyLeft < -(bodyWidth - outerWidth)) {
            this.tagBodyLeft = this.tagBodyLeft
          } else {
            this.tagBodyLeft = Math.max(this.tagBodyLeft + offset, outerWidth - bodyWidth)
          }
        } else {
          this.tagBodyLeft = 0
        }
      }
    },
    handleTagsOption (name) {
      let routeList = [this.list[0]]
      let nextRoute = {}
      if (name === 'close-others') {
        if (this.$route.name !== 'home') {
          routeList.push(this.$route)
        }
      }
      nextRoute = routeList[routeList.length - 1]
      this.afterCloseTags({ routeList, nextRoute })
    },
    handleClick (item) {
      if (item.name !== this.$route.name) {
        this.$router.push(item)
      }
    },
    handleClose (item, index) {
      let routeList = this.list
      let nextRoute = {}
      if (item.name === this.$route.name) {
        if (this.list.length > index + 1) {
          nextRoute = this.list[index + 1]
        } else {
          nextRoute = this.list[index - 1]
        }
      } else {
        nextRoute = this.$route
      }
      for (let i = 0; i < routeList.length; i++) {
        if (routeList[i].name === item.name) {
          routeList.splice(i, 1)
        }
      }
      this.afterCloseTags({ routeList, nextRoute })
    },
    addTagsNavList (route) {
      let currentTagsNavList = this.$store.state.app.tagsNavList
      if (currentTagsNavList.length === 0) {
        currentTagsNavList.push({
          name: 'home',
          path: '/',
          meta: {
            title: '首页'
          }
        })
      }
      let isNotNewRoute = currentTagsNavList.some((item) => {
        return item.name === route.name
      })
      if (!isNotNewRoute) {
        currentTagsNavList.push(route)
      }
      this.$store.dispatch('setTagsNavList', currentTagsNavList)
    },
    afterCloseTags (data) {
      let routeList = data.routeList
      let nextRoute = data.nextRoute
      this.$store.dispatch('setTagsNavList', routeList)
      if (nextRoute.name !== this.$route.name) {
        this.$router.replace(nextRoute)
      }
    }
  },
  watch: {
    '$route' (newRoute) {
      this.addTagsNavList(newRoute)
    }
  },
  mounted () {
  }
}
</script>

<style lang="less">
.no-select {
  -webkit-touch-callout: none;
  -webkit-user-select: none;
  -khtml-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}
.size {
  width: 100%;
  height: 100%;
}
.tags-nav {
  position: relative;
  border-top: 1px solid #f0f0f0;
  border-bottom: 1px solid #f0f0f0;
  z-index: 1;
  .no-select;
  .size;
  .close-con {
    position: absolute;
    right: 0;
    top: 0;
    height: 100%;
    width: 32px;
    background: #fff;
    text-align: center;
    z-index: 10;
  }
  .btn-con {
    position: absolute;
    top: 0px;
    height: 100%;
    background: #fff;
    padding-top: 3px;
    z-index: 10;
    button {
      padding: 6px 4px;
      line-height: 14px;
      text-align: center;
    }
    &.left-btn {
      left: 0px;
    }
    &.right-btn {
      right: 32px;
      border-right: 1px solid #f0f0f0;
    }
  }
  .scroll-outer {
    position: absolute;
    left: 28px;
    right: 61px;
    top: 0;
    bottom: 0;
    box-shadow: 0px 0 3px 2px rgba(100, 100, 100, 0.1) inset;
    .scroll-body {
      height: ~'calc(100% - 1px)';
      display: inline-block;
      padding: 1px 4px 0;
      position: absolute;
      overflow: visible;
      white-space: nowrap;
      transition: left 0.3s ease;
      .ivu-tag-dot-inner {
        transition: background 0.2s ease;
      }
    }
  }
  .contextmenu {
    position: absolute;
    margin: 0;
    padding: 5px 0;
    background: #fff;
    z-index: 1000;
    list-style-type: none;
    border-radius: 4px;
    box-shadow: 2px 2px 3px 0 rgba(0, 0, 0, 0.1);
    li {
      margin: 0;
      padding: 5px 15px;
      cursor: pointer;
      &:hover {
        background: #eee;
      }
    }
  }
}
</style>
