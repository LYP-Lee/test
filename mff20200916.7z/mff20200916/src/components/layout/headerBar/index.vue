<template>
  <div class="header-bar-wrapper">
    <div class="header-left">
      <slot name="left"></slot>
      <Reload></Reload>
      <div class="home-btn">
        <Breadcrumb>
          <BreadcrumbItem to="/">
            <span class="breadcrumb-item">
              <Icon type="md-home" size="18" />
              {{ $t('router.home') }}
            </span>
          </BreadcrumbItem>
        </Breadcrumb>
      </div>
      <Custom-bread-crumb v-if="$store.state.setting.nav.breadcrumb"></Custom-bread-crumb>
    </div>
    <div class="header-right">
      <slot name="right"></slot>
      <Header-base-menu></Header-base-menu>
    </div>
  </div>
</template>

<script>
import CustomBreadCrumb from '@/components/layout/customBreadCrumb'
import HeaderBaseMenu from '@/components/layout/headerBaseMenu'
import Reload from '@/components/reload'
export default {
  name: 'headerBar',
  components: {
    CustomBreadCrumb,
    HeaderBaseMenu,
    Reload
  },
  props: {

  },
  data () {
    return {

    }
  },
  created () { },
  mounted () { },
  updated () { },
  destroyed () { },
  methods: {},
  computed: {},
  watch: {}
}
</script>
<style lang="less" scoped>
.header-bar-wrapper {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.header-left,
.header-right {
  display: flex;
  align-items: center;
}
.home-btn {
  padding-right: 20px;
}
</style>
