<template>
    <div class="user-avatar-dropdown">
        <Dropdown @on-click="handleClick">
            <Avatar :src="userAvatar"/>
            <Icon :size="18" type="md-arrow-dropdown"></Icon>
            <DropdownMenu slot="list">
                <DropdownItem name="logout">退出登录</DropdownItem>
            </DropdownMenu>
        </Dropdown>
    </div>
</template>

<script>
export default {
  name: 'user',
  components: {
  },
  props: {
  },
  data () {
    return {
      userAvatar: ''
    }
  },
  created () {},
  mounted () {},
  updated () {},
  destroyed () {},
  methods: {
    handleClick (name) {
      console.log(name)
    }
  },
  computed: {},
  watch: {}
}
</script>
<style lang="less" scoped>
</style>
