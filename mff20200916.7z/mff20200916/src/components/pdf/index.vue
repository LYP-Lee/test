<template>
  <div class="pdf-container">
    <div class="pdf-box" v-if="src">
      <pdf v-for="i in numPages" :key="i" :src="src" :page="i" @page-loaded="pageLoaded"></pdf>
    </div>
  </div>
</template>

<script>

import pdf from 'vue-pdf'

export default {
  name: 'pdfDetails',
  components: {
    pdf
  },
  props: {
    url: {
      type: String,
      default: ''
    }
  },
  data () {
    return {
      src: '',
      numPages: undefined,
      totalPages: 0
    }
  },
  created () {
    this.initPdf()
  },
  mounted () {
    this.show()
  },
  methods: {
    initPdf () {
      if (!this.src) {
        return
      }
      var loadingTask = pdf.createLoadingTask(this.url)
      this.src = loadingTask
    },
    show () {
      if (!this.src) {
        return
      }
      this.src.promise.then(pdf => {
        this.totalPages = pdf.numPages
        this.numPages = 1
      })
    },
    pageLoaded (number) {
      if (this.numPages >= this.totalPages) {
        this.numPages = this.totalPages
      } else {
        this.numPages++
      }
    }
  }
}
</script>
<style scoped lang="less">
.pdf-container,
.pdf-box {
  position: relative;
  width: 100%;
}
</style>>
