<template>
  <div class="calendar-wrapper">
    <!-- 月 -->
    <div class="calendar-box" v-if="type=='month'">
      <div class="calendar-header">
        <div class="calendar-header-item">{{ $t('common.calendar.onSunday') }}</div>
        <div class="calendar-header-item">{{ $t('common.calendar.onMonday') }}</div>
        <div class="calendar-header-item">{{ $t('common.calendar.onTuesday') }}</div>
        <div class="calendar-header-item">{{ $t('common.calendar.onWednesday') }}</div>
        <div class="calendar-header-item">{{ $t('common.calendar.onThursday') }}</div>
        <div class="calendar-header-item">{{ $t('common.calendar.onFriday') }}</div>
        <div class="calendar-header-item">{{ $t('common.calendar.onSaturday') }}</div>
      </div>
      <div class="calendar-body">
        <div class="calendar-body-row" v-for="(item,index) in showData" :key="firstWeek+index">
          <div
            class="calendar-body-item"
            :class="{'no-current-month':cItem.month != showMonth,'today':cItem.date == currentDate && cItem.month == currentMonth && cItem.year == currentYear}"
            v-for="(cItem,cIndex) in item"
            :key="cItem.time+cIndex"
          >
            <span class="date-text" @click="handleMonthItemClick(cItem)">{{ cItem.date }}</span>
            <div class="info-box">
              <slot :data="cItem" name="info"></slot>
            </div>
          </div>
          <div class="tips-box">{{ $t('common.calendar.whichWeek',{number:firstWeek+index}) }}</div>
        </div>
      </div>
    </div>
    <!-- 年 -->
    <div class="year-box" v-if="type=='year'">
      <div class="year-item" @dblclick="handleYearItemClick(1)">
        <slot :data="1" name="year"></slot>
        <div class="year-item-text">{{ $t('common.calendar.January') }}</div>
      </div>
      <div class="year-item" @dblclick="handleYearItemClick(2)">
        <slot :data="2" name="year"></slot>
        <div class="year-item-text">{{ $t('common.calendar.February') }}</div>
      </div>
      <div class="year-item" @dblclick="handleYearItemClick(3)">
        <slot :data="3" name="year"></slot>
        <div class="year-item-text">{{ $t('common.calendar.March') }}</div>
      </div>
      <div class="year-item" @dblclick="handleYearItemClick(4)">
        <slot :data="4" name="year"></slot>
        <div class="year-item-text">{{ $t('common.calendar.April') }}</div>
      </div>
      <div class="year-item" @dblclick="handleYearItemClick(5)">
        <slot :data="5" name="year"></slot>
        <div class="year-item-text">{{ $t('common.calendar.May') }}</div>
      </div>
      <div class="year-item" @dblclick="handleYearItemClick(6)">
        <slot :data="6" name="year"></slot>
        <div class="year-item-text">{{ $t('common.calendar.June') }}</div>
      </div>
      <div class="year-item" @dblclick="handleYearItemClick(7)">
        <slot :data="7" name="year"></slot>
        <div class="year-item-text">{{ $t('common.calendar.July') }}</div>
      </div>
      <div class="year-item" @dblclick="handleYearItemClick(8)">
        <slot :data="8" name="year"></slot>
        <div class="year-item-text">{{ $t('common.calendar.August') }}</div>
      </div>
      <div class="year-item" @dblclick="handleYearItemClick(9)">
        <slot :data="9" name="year"></slot>
        <div class="year-item-text">{{ $t('common.calendar.September') }}</div>
      </div>
      <div class="year-item" @dblclick="handleYearItemClick(10)">
        <slot :data="10" name="year"></slot>
        <div class="year-item-text">{{ $t('common.calendar.October') }}</div>
      </div>
      <div class="year-item" @dblclick="handleYearItemClick(11)">
        <slot :data="11" name="year"></slot>
        <div class="year-item-text">{{ $t('common.calendar.November') }}</div>
      </div>
      <div class="year-item" @dblclick="handleYearItemClick(12)">
        <slot :data="12" name="year"></slot>
        <div class="year-item-text">{{ $t('common.calendar.December') }}</div>
      </div>
    </div>
    <!-- 星期 -->
    <div class="week-box" v-if="type=='week'">
      <div
        class="week-item"
        v-for="(item,index) in currentWeekDays"
        :key="index"
        :class="{'today':item.date == currentDate && item.month == currentMonth && item.year == currentYear}"
        @click="handleWeekItemClick(item)"
      >
        <div class="week-item-week">{{ weekText[index] }}</div>
        <div
          class="week-item-date"
        >{{ $t('common.calendar.date',{month:item.month,date:item.date,monthEnglish:item.monthEnglish}) }}</div>
      </div>
    </div>
    <!-- 日 -->
    <div class="day-box" v-if="type=='day'">
      <div
        class="day-item"
        v-for="(item,index) in timeDataText"
        :key="index"
        @click="handleDayItemClick(item)"
      >{{ item }}</div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'calendar',
  components: {
  },
  props: {
    showMonth: {
      type: Number,
      default: (new Date()).getMonth() + 1
    },
    showYear: {
      type: Number,
      default: (new Date()).getFullYear()
    },
    showDate: {
      type: Number,
      default: (new Date()).getDate()
    },
    type: {
      type: String,
      default: 'month'
    }
  },
  data () {
    return {
      currentMonth: (new Date()).getMonth() + 1,
      currentDate: (new Date()).getDate(),
      currentYear: (new Date()).getFullYear(),
      showData: [],
      currentWeekDays: [],
      timeDataText: [
        '00:00', '00:30', '01:00', '01:30',
        '02:00', '02:30', '03:00', '03:30',
        '04:00', '04:30', '05:00', '05:30',
        '06:00', '06:30', '07:00', '07:30',
        '08:00', '08:30', '09:00', '09:30',
        '10:00', '10:30', '11:00', '11:30',
        '12:00', '12:30', '13:00', '13:30',
        '14:00', '14:30', '15:00', '15:30',
        '16:00', '16:30', '17:00', '17:30',
        '18:00', '18:30', '19:00', '19:30',
        '20:00', '20:30', '21:00', '21:30',
        '22:00', '22:30', '23:00', '23:30'
      ]
    }
  },
  created () {
    this.getData()
    this.getWeekDays()
  },
  mounted () {
  },
  updated () { },
  destroyed () { },
  methods: {
    getYearWeek (year, month, date) {
      let date1 = new Date(year, parseInt(month) - 1, date);
      let date2 = new Date(year, 0, 1);
      let d = Math.round((date1.getTime() - date2.getTime()) / 86400000);
      return Math.ceil((d + ((date2.getDay() + 1) - 1)) / 7);
    },
    getData () {
      let firstDate = new Date(this.showYear, this.showMonth - 1, 1)
      let firstDateTime = firstDate.getTime()
      let firstDateDay = firstDate.getDay()
      let firstWeek = this.firstWeek
      let firstShowDate = 0
      let currentCalTime = 0
      firstShowDate = new Date(firstDateTime - 1000 * 60 * 60 * 24 * firstDateDay).getDate()
      currentCalTime = firstDateTime - 1000 * 60 * 60 * 24 * firstDateDay
      this.showData = []
      for (let i = 0; i < 5; i++) {
        let weekData = []
        for (let j = 0; j < 7; j++) {
          weekData.push(this.getDateDataByTime(currentCalTime))
          currentCalTime += 1000 * 60 * 60 * 24
        }
        this.showData.push(weekData)
      }
    },
    getWeekDays () {
      let firstDate = new Date(this.showYear, this.showMonth - 1, this.showDate)
      let firstDateTime = firstDate.getTime()
      let firstDateDay = firstDate.getDay()
      let firstWeek = this.firstWeek
      let firstShowDate = 0
      let currentCalTime = 0
      firstShowDate = new Date(firstDateTime - 1000 * 60 * 60 * 24 * firstDateDay).getDate()
      currentCalTime = firstDateTime - 1000 * 60 * 60 * 24 * firstDateDay
      this.currentWeekDays = []
      for (let j = 0; j < 7; j++) {
        this.currentWeekDays.push(this.getDateDataByTime(currentCalTime))
        currentCalTime += 1000 * 60 * 60 * 24
      }
      for (let i = 0; i < this.currentWeekDays.length; i++) {
        switch (this.currentWeekDays[i].month) {
          case 1:
            this.currentWeekDays[i]['monthEnglish'] = 'January'
            break;
          case 2:
            this.currentWeekDays[i]['monthEnglish'] = 'February'
            break;
          case 3:
            this.currentWeekDays[i]['monthEnglish'] = 'March'
            break;
          case 4:
            this.currentWeekDays[i]['monthEnglish'] = 'April'
            break;
          case 5:
            this.currentWeekDays[i]['monthEnglish'] = 'May'
            break;
          case 6:
            this.currentWeekDays[i]['monthEnglish'] = 'June'
            break;
          case 7:
            this.currentWeekDays[i]['monthEnglish'] = 'July'
            break;
          case 8:
            this.currentWeekDays[i]['monthEnglish'] = 'August'
            break;
          case 9:
            this.currentWeekDays[i]['monthEnglish'] = 'September'
            break;
          case 10:
            this.currentWeekDays[i]['monthEnglish'] = 'October'
            break;
          case 11:
            this.currentWeekDays[i]['monthEnglish'] = 'November'
            break;
          case 12:
            this.currentWeekDays[i]['monthEnglish'] = 'December'
            break;
        }
      }
    },
    changeData () {
      this.getData()
      this.getWeekDays()
    },
    getDateDataByTime (time) {
      let d = new Date(time)
      let year = d.getFullYear()
      let month = d.getMonth() + 1
      let date = d.getDate()
      let day = d.getDay()
      return { year, month, date, day, time }
    },
    handleMonthItemClick (val) {
      this.$emit('selectMonthItem', val)
    },
    handleYearItemClick (val) {
      this.$emit('selectYearItem', val)
    },
    handleWeekItemClick (val) {
      this.$emit('selectWeekItem', val)
    },
    handleDayItemClick (val) {
      this.$emit('selectDayItem', val)
    }
  },
  computed: {
    firstWeek () {
      return this.getYearWeek(this.showYear, this.showMonth, 1)
    },
    weekText () {
      return [
        this.$t('common.calendar.sunday'),
        this.$t('common.calendar.monday'),
        this.$t('common.calendar.tuesday'),
        this.$t('common.calendar.wednesday'),
        this.$t('common.calendar.thursday'),
        this.$t('common.calendar.friday'),
        this.$t('common.calendar.saturday')
      ]
    }
  },
  watch: {
    'showMonth': function (val) {
      this.changeData()
    },
    'showYear': function (val) {
      this.changeData()
    },
    'showDate': function (val) {
      this.changeData()
    }
  }
}
</script>
<style lang="less" scoped>
.calendar-wrapper {
  position: relative;
  width: 100%;
  height: 100%;
}
.calendar-box {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;
}
.calendar-header {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 38px;
  line-height: 38px;
  font-size: 18px;
  color: #333;
  font-weight: bold;
  &:hover {
    background: #fff;
  }
  .calendar-header-item {
    flex: 1;
    text-align: center;
    &:hover {
      background: #ededed;
    }
  }
}
.calendar-body {
  position: relative;
  flex: 1;
  display: flex;
  flex-direction: column;
  width: 100%;
  border: 1px solid #e1e1e1;
  .calendar-body-row {
    position: relative;
    flex: 1;
    width: 100%;
    display: flex;
    &:first-child {
      .calendar-body-item {
        border-top: 0;
      }
    }
    &:hover {
      background: #fff;
      .tips-box {
        display: block;
      }
    }
  }
  .tips-box {
    display: none;
    font-size: 18px;
    color: #333;
    position: fixed;
    transform: translate(-100%);
    height: 40px;
    padding: 0 10px;
    line-height: 40px;
    border: 1px solid #e1e1e1;
    z-index: 11111;
    background: #fff;
  }
  .calendar-body-item {
    font-size: 16px;
    color: #333;
    position: relative;
    flex: 1;
    height: 100%;
    text-align: right;
    box-sizing: border-box;
    padding: 10px;
    border-left: 1px solid #e1e1e1;
    border-top: 1px solid #e1e1e1;
    &:hover {
      background: #ededed;
    }
    &:first-child {
      border-left: 0;
    }
    &:nth-child(7),
    &:nth-child(1) {
      color: darkred;
    }
    &.today {
      font-size: 20px;
      color: #000;
      background: #b6ccde;
      font-weight: bold;
    }
    &.no-current-month {
      .date-text {
        opacity: 0.2;
      }
    }
    .date-text {
      cursor: pointer;
    }
    .info-box {
      position: absolute;
      bottom: 0;
      left: 0;
      z-index: 11;
    }
  }
}
.year-box {
  display: flex;
  width: 100%;
  align-items: center;
  flex-wrap: wrap;
  .year-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    text-align: center;
    min-width: 25%;
    height: 60px;
    border-right: 1px solid #e1e1e1;
    border-bottom: 1px solid #e1e1e1;
    box-sizing: border-box;
    cursor: pointer;
    user-select: none;
    &:nth-child(1),
    &:nth-child(2),
    &:nth-child(3),
    &:nth-child(4) {
      border-top: 1px solid #e1e1e1;
    }
    &:nth-child(1),
    &:nth-child(5),
    &:nth-child(9) {
      border-left: 1px solid #e1e1e1;
    }
  }
  .year-item-text {
    flex: 1;
    padding: 0 20px;
    text-align: right;
    box-sizing: border-box;
  }
}
.week-box {
  width: 100%;
  display: flex;
  align-items: center;
  .week-item {
    flex: 1;
    display: flex;
    flex-direction: column;
    text-align: center;
    justify-content: center;
    box-sizing: border-box;
    height: 60px;
    border: 1px solid #e1e1e1;
    border-left: 0;
    cursor: pointer;
    &:first-child {
      border-left: 1px solid #e1e1e1;
    }
    &.today {
      background: #b6ccde;
    }
  }
  .week-item-week {
    color: #333;
    font-weight: bold;
  }
}
.day-box {
  width: 100%;
  padding: 10px 0;
  .day-item {
    font-size: 14px;
    color: #333;
    font-weight: 700;
    height: 30px;
    line-height: 30px;
    padding-left: 10px;
    border-bottom: 1px dashed #e1e1e1;
    &:nth-child(4n + 1),
    &:nth-child(4n + 2) {
      background: #fff;
    }
  }
}
</style>
