<template>
  <div class="list-wrapper">
    <div class="icon-list-container">
      <div
        class="icon-list-item"
        :style="{width:width,height:height}"
        v-for="(item,index) in list"
        :key="index"
        @click="handleItemClick(item)"
      >
        <div class="icon-list-content">
          <div class="icon-sign-box">
            <slot name="sign" :data="item"></slot>
          </div>
          <slot name="iconBtn" :data="item"></slot>
          <div
            class="img-box"
            v-if="(item[showTypeKey] && item[showTypeKey] == 'image') || !showTypeKey"
          >
            <img :src="item[showPreviewKey]" />
          </div>
          <div class="video-box" v-if="(item[showTypeKey] && item[showTypeKey] == 'video')">
            <video :src="item[showPreviewKey]" controls="controls"></video>
          </div>
          <div
            class="other-box"
            v-if="!(item[showTypeKey] && (item[showTypeKey] == 'video' || item[showTypeKey] == 'image')) && showTypeKey"
          >
            <slot name="icon" :data="item"></slot>
          </div>
        </div>
        <div
          class="icon-list-name"
          @click="handleFileNameClick(item,$event)"
        >{{ item[showNameKey] }}</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'list',
  components: {
  },
  props: {
    type: {
      type: String,
      default: 'icon'
    },
    list: {
      type: Array,
      default () {
        return []
      }
    },
    showNameKey: {
      type: String,
      default: ''
    },
    showPreviewKey: {
      type: String,
      default: ''
    },
    showTypeKey: {
      type: String,
      default: ''
    },
    width: {
      type: String,
      default: ''
    },
    height: {
      type: String,
      default: ''
    }
  },
  data () {
    return {
    }
  },
  created () {
  },
  mounted () {
  },
  updated () { },
  destroyed () { },
  methods: {
    handleItemClick (val) {
      this.$emit('handleItemClick', val)
    },
    handleFileNameClick (val, e) {
      e.stopPropagation();
      this.$emit('handleFileNameClick', val)
    }
  },
  computed: {
  },
  watch: {
  }
}
</script>
<style lang="less" scoped>
.list-wrapper {
  position: relative;
}
.icon-list-container {
  display: flex;
  flex-wrap: wrap;
}
.icon-list-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  margin: 0 10px 20px;
  box-sizing: border-box;
  border: 1px solid rgba(255, 255, 255, 0);
  &:hover {
    border: 1px solid #1a92e1;
  }
}
.icon-list-name {
  font-size: 14px;
  width: 100%;
  height: 40px;
  line-height: 40px;
  text-align: center;
  color: #337ab7;
  cursor: default;
}
.icon-list-content {
  position: relative;
  flex: 1;
  width: 100%;
  overflow: hidden;
  .icon-sign-box {
    position: absolute;
    top: 0;
    left: 0;
    z-index: 1111;
  }
  .img-box {
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    width: 100%;
    height: 100%;
    overflow: hidden;
    background: #e0e0e0;
    img {
      height: 100%;
      width: auto;
    }
  }
  .video-box {
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    width: 100%;
    height: 100%;
    overflow: hidden;
    background: #e0e0e0;
    video {
      width: 100%;
      height: 100%;
    }
  }
  .other-box {
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    width: 100%;
    height: 100%;
    overflow: hidden;
    background: #e0e0e0;
  }
}
</style>
