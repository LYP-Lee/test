<template>
  <div class="global-wrapper" v-if="loading">
    <Spin fix>
      <Icon type="ios-loading" size="26" class="demo-spin-icon-load"></Icon>
      <div>Loading</div>
    </Spin>
  </div>
</template>
<script>
export default {
  data () {
    return {
      loading: false
    }
  },
  computed: {
  },
  methods: {
    show () {
      this.loading = true
    },
    hide () {
      this.loading = false
    }
  }
}
</script>
<style lang="less" scoped>
.global-wrapper {
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  z-index: 111111111;
}
.demo-spin-icon-load {
  animation: ani-demo-spin 1s linear infinite;
}
@keyframes ani-demo-spin {
  from {
    transform: rotate(0deg);
  }
  50% {
    transform: rotate(180deg);
  }
  to {
    transform: rotate(360deg);
  }
}
</style>>