import Vue from 'vue'
import Loading from './index.vue'

const GlobalLoading = Vue.extend(Loading)
let $vm = new GlobalLoading({
  el: document.createElement('div'),
  data () { }
})
document.body.appendChild($vm.$el);
let loading = {
  show () {
    $vm.show()
  },
  hide () {
    $vm.hide()
  },
  moveEl (id) {
    document.getElementById(id).appendChild($vm.$el)
  }
};
export default loading