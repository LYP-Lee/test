import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import Lockr from 'lockr'
import Util from '@/libs/util'
import 'xe-utils'
import '@/plugins/vxeTable'
import { loadLanguageAsync, i18n } from '@/lang'
import Directive from '@/directive'
import Mixin from '@/mixin'
import {
  LoadingBar,
  Button,
  Layout,
  Sider,
  Header,
  Content,
  Menu,
  Submenu,
  Icon,
  MenuItem,
  MenuGroup,
  Breadcrumb,
  BreadcrumbItem,
  Dropdown,
  DropdownMenu,
  DropdownItem,
  Avatar,
  FormItem,
  Form,
  Input,
  Tag,
  Tooltip,
  Drawer,
  Switch,
  Spin,
  Upload,
  ButtonGroup,
  DatePicker
} from 'view-design'
import '@/assets/less/myTheme/default.less'

Vue.config.productionTip = false
Vue.component('Button', Button)
Vue.component('Layout', Layout)
Vue.component('Sider', Sider)
Vue.component('Header', Header)
Vue.component('Content', Content)
Vue.component('Menu', Menu)
Vue.component('Submenu', Submenu)
Vue.component('Icon', Icon)
Vue.component('MenuItem', MenuItem)
Vue.component('MenuGroup', MenuGroup)
Vue.component('Breadcrumb', Breadcrumb)
Vue.component('BreadcrumbItem', BreadcrumbItem)
Vue.component('Dropdown', Dropdown)
Vue.component('DropdownMenu', DropdownMenu)
Vue.component('DropdownItem', DropdownItem)
Vue.component('Avatar', Avatar)
Vue.component('Form', Form)
Vue.component('FormItem', FormItem)
Vue.component('Input', Input)
Vue.component('Tag', Tag)
Vue.component('Tooltip', Tooltip)
Vue.component('Drawer', Drawer)
Vue.component('IviewSwitch', Switch)
Vue.component('Spin', Spin)
Vue.component('Upload', Upload)
Vue.component('ButtonGroup', ButtonGroup)
Vue.component('DatePicker', DatePicker)
Vue.use(Directive)
Vue.use(Mixin)

router.beforeEach((to, from, next) => {
  let lang = i18n.locale
  let authorization = Lockr.get('authorization')
  let csrfToken = Lockr.get('X-XSRF-TOKEN')

  LoadingBar.start()
  Util.title(to.meta.title)

  if (!to.meta.isCheck) {
    loadLanguageAsync(lang).then(() => {
      if (to.meta.title && to.meta.title.indexOf('.') > -1) {
        Util.title(i18n.t(to.meta.title))
      }
      next()
    })
  } else if (authorization && csrfToken) {
    if (JSON.stringify(store.state.user) === '{}') {
      store.commit('setAuthorization', authorization)
      store.commit('setCsrfToken', csrfToken)
      store.commit('setLang', lang)
    }
    loadLanguageAsync(lang).then(() => {
      if (to.meta.title.indexOf('.') > -1) {
        Util.title(i18n.t(to.meta.title))
      }
      next()
    })
  } else {
    // 未登录跳转...
    /* next({
      name: 'login'
    }) */
  }
})

router.afterEach((to, from, next) => {
  LoadingBar.finish()
  window.scrollTo(0, 0)
})

new Vue({
  i18n,
  router,
  store,
  render: h => h(App)
}).$mount('#app')
Vue.prototype.$loading = false