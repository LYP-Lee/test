<template>
  <div id="app">
    <!-- <div id="nav">
      <router-link to="/">Home</router-link> |
      <router-link to="/about">About</router-link>
    </div>-->
    <router-view />
  </div>
</template>
<script>
export default {
  data () {
    return {}
  },
  props: {},
  created () {
    this.init()
  },
  mounted () {

  },
  methods: {
    init () {
      this.initLanguage()
    },
    initLanguage () {
      let currLang = navigator.appName === 'Netscape' ? navigator.language : navigator.browserLanguage
      currLang = currLang.indexOf('en') > -1 ? 'en' : currLang
      currLang = currLang.indexOf('zh-CN') > -1 ? 'zh' : currLang
      currLang = currLang.indexOf('zh-TW') > -1 ? 'zh-TW' : currLang
      this.$i18n.locale = currLang
    }
  }
}
</script>>
<style lang="scss">
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

#nav {
  padding: 30px;
  a {
    font-weight: bold;
    color: #2c3e50;

    &.router-link-exact-active {
      color: #42b983;
    }
  }
}
</style>
