<template>
  <div class="children-main">
    <keep-alive :exclude="$store.getters.notCacheList">
      <router-view v-if="$store.state.app.isRouteActive"></router-view>
    </keep-alive>
  </div>
</template>
