<template>
  <div class="login-wrapper">
    <div class="header">
      <div class="header-items">
        <Language></Language>
      </div>
    </div>
    <div class="content">
      <div class="form-box">
        <div class="form-header">欢迎登录</div>
        <div class="form-content">
          <Login-form @on-success-valid="loginSuccess"></Login-form>
        </div>
        <div class="form-footer">输入用户名和密码</div>
      </div>
    </div>
    <div class="footer">
      <p class="footer-info">
        <a href="javascript:void(0);">
          <span class="footer-info-text">tttttttttttttttttttt</span>
        </a>
      </p>
    </div>
  </div>
</template>

<script>
import LoginForm from '@/components/loginForm'
import Language from '@/components/layout/language'
export default {
  name: 'login',
  components: {
    LoginForm,
    Language
  },
  props: {},
  data () {
    return {}
  },
  created () { },
  mounted () {
  },
  updated () { },
  destroyed () { },
  methods: {
    loginSuccess (data) {
      let userName = data.userName
      let password = data.password
      console.log(userName, password)
      this.$router.push({
        name: 'home'
      })
    }
  },
  computed: {},
  watch: {}
}
</script>
<style lang="less" scoped>
.login-wrapper{
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}
.header{
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  .header-items{
    display: flex;
    align-items: center;
    justify-content: center;
    position: absolute;
    right: 40px;
    top: 0;
    height: 40px;
  }
}
.content{
  width: 100%;
  height: 100%;
  background: rgb(29, 27, 27);
}
.footer{
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  text-align: center;
  font-size: 20px;
  padding: 10px 0;
  .footer-info-text{
    color: #fff;
  }
}
.form-box{
  font-size: 14px;
  position: absolute;
  top: 50%;
  right: 10%;
  transform: translateY(-50%);
  z-index: 11;
  border-radius: 6px;
  width: 300px;
  box-sizing: border-box;
  background: #fff;
  .form-header{
    padding: 14px 16px;
    border-bottom: 1px solid #e8eaec;
    color: #17233d;
    text-align: left;
    font-weight: bold;
  }
  .form-content{
    padding: 16px;
    padding-bottom: 0;
  }
  .form-footer{
    color: #c3c3c3;
    text-align: center;
    padding-bottom: 16px;
  }
}
</style>
