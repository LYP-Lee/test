<template>
  <div class="add-route-wrapper">
    <div class="header">
      <h1>动态添加路由</h1>
    </div>
    <div class="content">
      <div class="content-item">
        <h2>使用</h2>
        <p>调用libs/utils.js 中addRoutes方法动态添加路由</p>
      </div>
      <div class="content-item">
        <h2>注意</h2>
        <p>由于使用国际化语言，必须动态添加语言(this.$i18n.mergeLocaleMessage( locale, message )方法)，或是提前写好对应的语言</p>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'addRoutesPage',
  data () {
    return {
    }
  },
  components: {
  },
  computed: {
  },
  methods: {
  },
  watch: {
  },
  created () {
  },
  mounted () {

  }
}
</script>
<style lang='less' scoped>
.content-item {
  text-align: left;
  padding: 20px;
  p {
    padding-top: 10px;
  }
}
</style>>
