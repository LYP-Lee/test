<template>
  <div class="error-wrapper">
    <Error-content code="500" desc="Oh~~鬼知道服务器经历了什么~" :src="src" />
  </div>
</template>

<script>
import error404 from '@/assets/images/error-page/error-500.svg'
import ErrorContent from '@/components/errorContent'
export default {
  name: 'error_page_500',
  components: {
    ErrorContent
  },
  data () {
    return {
      src: error404
    }
  }
}
</script>
<style lang="less" scoped>
.error-wrapper {
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}
</style>
