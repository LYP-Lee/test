<template>
  <div class="list-wrapper">
    <div class="header">
      <h1>cms定制列表组件</h1>
    </div>
    <div class="content">
      <div class="content-item">
        <h2>使用示例</h2>
        <div class="example-box">
          <List
            :list="list"
            showNameKey="fileName"
            showPreviewKey="url"
            showTypeKey="type"
            width="380px"
            height="260px"
            @handleItemClick="handleItemClick"
            @handleFileNameClick="handleFileNameClick"
          >
            <template v-slot:icon="iconData">
              <div>其他文件-{{ iconData.data.fileName }}</div>
            </template>
            <template v-slot:sign="iconData">自定义sign{{ iconData.data.id }}</template>
            <template v-slot:iconBtn="iconData">
              <Button class="icon-btn">自定义按钮{{ iconData.data.id }}</Button>
            </template>
          </List>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import List from '@/components/cms/list'
export default {
  name: 'cmsList',
  data () {
    return {
      list: [{
        id: 11,
        fileName: '文件1',
        url: 'https://dev-file.iviewui.com/userinfoPDvn9gKWYihR24SpgC319vXY8qniCqj4/avatar',
        type: 'image'
      }, {
        id: 22,
        fileName: '文件2',
        url: 'https://dev-file.iviewui.com/userinfoPDvn9gKWYihR24SpgC319vXY8qniCqj4/avatar',
        type: 'image'
      }, {
        id: 33,
        fileName: '文件3',
        url: 'https://dev-file.iviewui.com/userinfoPDvn9gKWYihR24SpgC319vXY8qniCqj4/avatar',
        type: 'image'
      }, {
        id: 44,
        fileName: '文件4',
        url: 'https://dev-file.iviewui.com/userinfoPDvn9gKWYihR24SpgC319vXY8qniCqj4/avatar',
        type: 'image'
      }, {
        id: 76555,
        fileName: '文件666r44',
        url: 'https://dev-file.iviewui.com/userinfoPDvn9gKWYihR24SpgC319vXY8qniCqj4/avatar',
        type: 'video'
      }, {
        id: 444,
        fileName: '文件4444',
        url: 'https://dev-file.iviewui.com/userinfoPDvn9gKWYihR24SpgC319vXY8qniCqj4/avatar',
        type: 'file'
      }, {
        id: 55,
        fileName: '文件5',
        url: 'https://dev-file.iviewui.com/userinfoPDvn9gKWYihR24SpgC319vXY8qniCqj4/avatar',
        type: 'image'
      }, {
        id: 66,
        fileName: '文件6',
        url: 'https://dev-file.iviewui.com/userinfoPDvn9gKWYihR24SpgC319vXY8qniCqj4/avatar',
        type: 'image'
      }, {
        id: 77,
        fileName: '文件7',
        url: 'https://dev-file.iviewui.com/userinfoPDvn9gKWYihR24SpgC319vXY8qniCqj4/avatar',
        type: 'image'
      }, {
        id: 88,
        fileName: '文件8',
        url: 'https://dev-file.iviewui.com/userinfoPDvn9gKWYihR24SpgC319vXY8qniCqj4/avatar',
        type: 'image'
      }]
    }
  },
  components: {
    List
  },
  computed: {

  },
  methods: {
    handleItemClick (val) {
      console.log(val)
    },
    handleFileNameClick (val) {
      console.log(val)
    }
  },
  created () {

  },
  mounted () {

  }
}
</script>
<style lang='less' scoped>
.content-item {
  text-align: left;
  padding: 20px;
  p {
    padding-top: 10px;
  }
}
.icon-btn {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  z-index: 11;
}
</style>>
