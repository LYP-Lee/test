<template>
  <div class="theme-wrapper">
    <div class="header">
      <h1>cms定制calendar组件</h1>
    </div>
    <div class="content">
      <div class="content-item">
        <h2>使用示例</h2>
        <div class="example-box">
          <div class="example-header">
            <div class="example-header-date">
              <div v-if="type == 'year'">{{ year }}年</div>
              <div v-if="type == 'month'">{{ year }}年 {{ month }}月</div>
              <div v-if="type == 'week'">{{ year }}年 {{ week }}周</div>
              <div v-if="type == 'day'">{{ year }}年 {{ month }}月{{ date }}日， {{ currentWeek }}</div>
            </div>
            <div class="example-header-btn">
              <div class="example-header-btn-item">
                <ButtonGroup>
                  <Button type="primary" @click="showLast()">《 上一页</Button>
                  <Button @click="showToday()">今天</Button>
                  <Button type="primary" @click="showNext()">下一页 》</Button>
                </ButtonGroup>
              </div>
              <div class="example-header-btn-item">
                <DatePicker
                  type="date"
                  placeholder="Select date"
                  style="width: 200px"
                  :value="dateTimeValue"
                  @on-change="dateTimeChange"
                ></DatePicker>
              </div>
              <div class="example-header-btn-item">
                <ButtonGroup>
                  <Button type="primary" @click="changeType('year')">年</Button>
                  <Button type="primary" @click="changeType('month')">月</Button>
                  <Button type="primary" @click="changeType('week')">星期</Button>
                  <Button type="primary" @click="changeType('day')">日</Button>
                </ButtonGroup>
              </div>
            </div>
          </div>
          <div style="height:400px">
            <CMS-calendar
              :showMonth="month"
              :showYear="year"
              :showDate="date"
              @selectMonthItem="selectMonthItem"
              @selectYearItem="selectYearItem"
              @selectWeekItem="selectWeekItem"
              @selectDayItem="selectDayItem"
              :type="type"
              ref="calendar"
            >
              <template v-slot:info="itemData">
                <div class="calendar-info-box">
                  自定义
                  <Icon type="ios-bug-outline" />
                  {{ itemData.data.date }}
                </div>
              </template>
              <template v-slot:year="data">
                <div>自定义{{ data.data }}</div>
              </template>
            </CMS-calendar>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import CMSCalendar from '@/components/cms/calendar'
export default {
  name: 'cmsCalendarPage',
  data () {
    return {
      month: (new Date()).getMonth() + 1,
      year: (new Date()).getFullYear(),
      date: (new Date()).getDate(),
      type: "month"
    }
  },
  components: {
    CMSCalendar
  },
  computed: {
    dateTimeValue () {
      return `${this.year}-${this.month}-${this.date}`
    },
    week () {
      return this.$refs.calendar.getYearWeek(this.year, this.month, this.date)
    },
    currentWeek () {
      let currentDay = (new Date(this.year, this.month - 1, this.date)).getDay()
      let dayStr = ''
      switch (currentDay) {
        case 0:
          dayStr = this.$t('common.calendar.onSunday')
          break;
        case 1:
          dayStr = this.$t('common.calendar.onMonday')
          break;
        case 2:
          dayStr = this.$t('common.calendar.onTuesday')
          break;
        case 3:
          dayStr = this.$t('common.calendar.onWednesday')
          break;
        case 4:
          dayStr = this.$t('common.calendar.onThursday')
          break;
        case 5:
          dayStr = this.$t('common.calendar.onFriday')
          break;
        case 6:
          dayStr = this.$t('common.calendar.onSaturday')
          break;
      }
      return dayStr
    }
  },
  methods: {
    showLast () {
      let currShowDate = new Date(this.year, this.month - 1, this.date)
      let currShowTime = currShowDate.getTime()
      if (this.type === 'year') {
        return
      }
      if (this.type === 'month') {
        this.month--;
        if (this.month < 1) {
          this.month = 12
          this.year--
        }
      }
      if (this.type === 'week') {
        currShowTime -= 1000 * 60 * 60 * 24 * 7
        this.year = (new Date(currShowTime)).getFullYear()
        this.month = (new Date(currShowTime)).getMonth() + 1
        this.date = (new Date(currShowTime)).getDate()
      }
      if (this.type === 'day') {
        currShowTime -= 1000 * 60 * 60 * 24
        this.year = (new Date(currShowTime)).getFullYear()
        this.month = (new Date(currShowTime)).getMonth() + 1
        this.date = (new Date(currShowTime)).getDate()
      }
    },
    showNext () {
      let currShowDate = new Date(this.year, this.month - 1, this.date)
      let currShowTime = currShowDate.getTime()
      if (this.type === 'year') {
        return
      }
      if (this.type === 'month') {
        this.month++
        if (this.month > 12) {
          this.month = 1
          this.year++
        }
      }
      if (this.type === 'week') {
        currShowTime += 1000 * 60 * 60 * 24 * 7
        this.year = (new Date(currShowTime)).getFullYear()
        this.month = (new Date(currShowTime)).getMonth() + 1
        this.date = (new Date(currShowTime)).getDate()
      }
      if (this.type === 'day') {
        currShowTime += 1000 * 60 * 60 * 24
        this.year = (new Date(currShowTime)).getFullYear()
        this.month = (new Date(currShowTime)).getMonth() + 1
        this.date = (new Date(currShowTime)).getDate()
      }
    },
    showToday () {
      let date = new Date()
      this.month = date.getMonth() + 1
      this.year = date.getFullYear()
      this.date = date.getDate()
    },
    changeType (type) {
      this.type = type
    },
    dateTimeChange (val) {
      if (val) {
        let dateArr = val.split('-')
        this.year = parseInt(dateArr[0])
        this.month = parseInt(dateArr[1])
        this.date = parseInt(dateArr[2])
      }
    },
    selectMonthItem (val) {
      console.log(val)
      this.date = val.date
      this.type = 'day'
    },
    selectYearItem (val) {
      console.log(val)
      this.month = val
      this.type = 'month'
    },
    selectWeekItem (val) {
      this.date = val.date
      this.type = 'day'
    },
    selectDayItem (val) {
      console.log(val)
    }
  },
  watch: {
  },
  created () {
  },
  mounted () {
  }
}
</script>
<style lang='less' scoped>
.content-item {
  text-align: left;
  padding: 20px;
  p {
    padding-top: 10px;
  }
}
.example-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 0;
}
.example-header-date {
  font-size: 18px;
  padding-left: 20px;
}
.example-header-btn {
  display: flex;
  align-items: center;
}
.example-header-btn-item {
  padding-right: 20px;
}
</style>>
