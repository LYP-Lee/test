<template>
  <div>
    <div class="cropper-example cropper-first">
      <cropper
        :src="exampleImageSrc"
        :crop-button-text="`${$t('common.commit')}`"
        @on-crop="handleCroped"
      ></cropper>
    </div>
  </div>
</template>

<script>
import Cropper from '@/components/cropper'
export default {
  name: 'cropperPage',
  components: {
    Cropper
  },
  data () {
    return {
      exampleImageSrc: ''
    }
  },
  methods: {
    handleCroped (blob) {
      const formData = new FormData()
      formData.append('croppedImg', blob)
    }
  }
}
</script>

<style lang="less">
.cropper-example {
  height: 400px;
}
</style>
