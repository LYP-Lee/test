<template>
  <div class="theme-wrapper">
    <div class="header">
      <h1>v-loading自定义指令</h1>
    </div>
    <div class="content">
      <div class="content-item">
        <h2>使用示例</h2>
        <div class="test" v-loading="loading">这是一个v-loading的演示模块</div>
        <Button @click="handleLoading()">显示/隐藏loading</Button>
      </div>
      <div class="content-item">
        <h2>使用方法</h2>
        <p>直接在元素上调用v-loading指令,绑定值为true/false</p>
        <p>另外，还可以调用this.$loading.show()显示全局的loading,调用this.$loading.hide()隐藏全局的loading，调用this.$loading.moveEl('content')可以将全局的loading放到指定的元素</p>
      </div>
    </div>
  </div>
</template>
<script>

export default {
  name: 'loadingPage',
  data () {
    return {
      loading: true
    }
  },
  components: {
  },
  computed: {
  },
  methods: {
    handleLoading () {
      this.loading = !this.loading
    }
  },
  watch: {
  },
  created () {

  },
  mounted () {
  }
}
</script>
<style lang='less' scoped>
.content-item {
  text-align: left;
  padding: 20px;
  p {
    padding-top: 10px;
  }
}
.test {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 400px;
  height: 200px;
  border: 1px solid #000;
  border-radius: 5px;
  overflow: hidden;
}
</style>>
