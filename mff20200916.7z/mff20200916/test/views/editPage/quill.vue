<template>
  <div class="theme-wrapper">
    <div class="header">
      <h1>vue-quill-editor编辑器组件</h1>
    </div>
    <div class="content">
      <div class="content-item">
        <h2>使用示例</h2>
        <p>
          <quill-editor
            ref="myQuillEditor"
            v-model="content"
            :options="editorOption"
            @blur="onEditorBlur($event)"
            @focus="onEditorFocus($event)"
            @ready="onEditorReady($event)"
          />
        </p>
        <p>
          <span style="color:orangered">内容：</span>
        </p>
        <p v-html="content" class="ql-editor"></p>
      </div>
      <div class="content-item">
        <h2>github地址</h2>
        <p>
          <a
            href="https://github.com/surmon-china/vue-quill-editor"
            target="parent"
          >https://github.com/surmon-china/vue-quill-editor</a>
        </p>
      </div>
      <div class="content-item">
        <h2>注意</h2>
        <p>协议：MIT Licence.</p>
      </div>
    </div>
  </div>
</template>
<script>
import 'quill/dist/quill.core.css'
import 'quill/dist/quill.snow.css'
import 'quill/dist/quill.bubble.css'

import { quillEditor } from 'vue-quill-editor'
export default {
  name: 'quillePage',
  data () {
    return {
      content: '',
      editorOption: {}
    }
  },
  components: {
    quillEditor
  },
  computed: {
  },
  methods: {
    onEditorBlur () {

    },
    onEditorFocus () {

    },
    onEditorReady () {

    }
  },
  watch: {
  },
  created () {

  },
  mounted () {
  }
}
</script>
<style lang='less' scoped>
.content-item {
  text-align: left;
  padding: 20px;
  p {
    padding-top: 10px;
  }
}
/deep/.ql-container {
  min-height: 300px;
}
</style>>
