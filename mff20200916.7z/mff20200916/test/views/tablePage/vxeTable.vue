<template>
  <div class="select-wrapper">
    <div class="header">
      <h1>vxe-table表格组件</h1>
    </div>
    <div class="content">
      <div class="content-item">
        <h2>使用示例</h2>
        <p>
          <span style="color:orangered">基础示例</span>
          <vxe-toolbar>
            <template v-slot:buttons>
              <vxe-button @click="allAlign = 'left'">居左</vxe-button>
              <vxe-button @click="allAlign = 'center'">居中</vxe-button>
              <vxe-button @click="allAlign = 'right'">居右</vxe-button>
            </template>
          </vxe-toolbar>

          <vxe-table border="inner" :align="allAlign" :data="tableData">
            <vxe-table-column type="seq" width="60"></vxe-table-column>
            <vxe-table-column field="name" title="名称"></vxe-table-column>
            <vxe-table-column field="sex" title="性别"></vxe-table-column>
            <vxe-table-column field="age" title="年龄"></vxe-table-column>
          </vxe-table>
        </p>
        <p>
          <span class="other-header">
            <span style="color:orangered">其它演示</span>
            <FullScreenComponents id="fullScreen"></FullScreenComponents>
          </span>
          <iframe
            class="iframe"
            id="fullScreen"
            src="https://xuliangzhan_admin.gitee.io/vxe-table/#/table/base/basic"
          ></iframe>
        </p>
      </div>
      <div class="content-item">
        <h2>github地址</h2>
        <p>
          <a
            href="https://github.com/x-extends/vxe-table"
            target="parent"
          >https://github.com/x-extends/vxe-table</a>
        </p>
      </div>
      <div class="content-item">
        <h2>文档地址</h2>
        <p>
          <a
            href="https://xuliangzhan_admin.gitee.io/vxe-table/#/table/api"
            target="parent"
          >https://xuliangzhan_admin.gitee.io/vxe-table/#/table/api</a>
        </p>
      </div>
      <div class="content-item">
        <h2>演示地址</h2>
        <p>
          <a
            href="https://xuliangzhan_admin.gitee.io/vxe-table/#/table/base/basic"
            target="parent"
          >https://xuliangzhan_admin.gitee.io/vxe-table/#/table/base/basic</a>
        </p>
      </div>
      <div class="content-item">
        <h2>注意</h2>
        <p>协议：MIT Licence.</p>
      </div>
    </div>
  </div>
</template>
<script>
import FullScreenComponents from '@/components/fullScreen'
export default {
  name: 'vxeTablePage',
  data () {
    return {
      allAlign: null,
      tableData: [
        { id: 10001, name: '张三', sex: '男', age: 18 },
        { id: 10002, name: '李四', sex: '女', age: 19 },
        { id: 10003, name: '王五', sex: '男', age: 20 }
      ]
    }
  },
  components: {
    FullScreenComponents
  },
  computed: {
  },
  methods: {
  },
  watch: {
  },
  created () {
  },
  mounted () {
  }
}
</script>
<style lang='less' scoped>
.content-item {
  text-align: left;
  padding: 20px;
  p {
    padding-top: 10px;
  }
}
.iframe {
  display: block;
  width: 90%;
  height: 800px;
  border: 1px solid #ddd;
}
.other-header {
  display: flex;
  align-items: center;
}
</style>>
