<template>
  <div class="theme-wrapper">
    <div class="header">
      <h1>移动组件</h1>
    </div>
    <div class="content">
      <div class="content-item">
        <h2>使用方法</h2>
        <p>import Move from '@/components/move'引入组件，注册并使用</p>
      </div>
      <div class="content-item">
        <h2>使用示例</h2>
        <div class="test-container">
          <div class="test-item">测试</div>
          <Move>
            <div class="test-item test-item2">测试二</div>
          </Move>
          <div class="test-item">测试</div>
          <div class="test-item">测试</div>
          <div class="test-item">测试</div>
          <div class="test-item">测试</div>
          <div class="test-item">测试</div>
          <div class="test-item">测试</div>
          <Move>
            <div class="test-item" style="background:yellow;color:orangered">测试test</div>
          </Move>
          <div class="test-item">测试</div>
          <div class="test-item">测试</div>
          <div class="test-item">测试</div>
          <div class="test-item">测试</div>
          <div class="test-item">测试</div>
          <div class="test-item">测试</div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import Move from '@/components/move'
export default {
  name: 'movePage',
  data () {
    return {}
  },
  components: {
    Move
  },
  computed: {

  },
  methods: {

  },
  created () {
  },
  mounted () {

  }
}
</script>
<style lang='less' scoped>
.content-item {
  text-align: left;
  padding: 20px;
  p {
    padding-top: 10px;
  }
}
.test-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
}
.test-item {
  width: 300px;
  height: 300px;
  border: 1px solid #ddd;
  border-radius: 6px;
  background: rgb(77, 236, 215);
  box-sizing: border-box;
  padding: 10px;
  margin-bottom: 20px;
  &.test-item2 {
    background: orangered;
    color: #fff;
  }
}
</style>>
