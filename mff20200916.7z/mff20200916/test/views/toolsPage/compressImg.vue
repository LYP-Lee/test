<template>
  <div class="theme-wrapper">
    <div class="header">
      <h1>压缩图片组件</h1>
    </div>
    <div class="content">
      <div class="content-item">
        <h2>使用方法</h2>
        <p>import util from '@/libs/util'</p>
        <p>util.compressImg(file, type, compressSize, isCompress)</p>
      </div>
      <div class="content-item">
        <h2>使用示例</h2>
        <div class="file-input-box">
          <div class="file-input-item">
            <p>本地图片</p>
            <Upload :before-upload="handleUpload" action>
              <Button icon="ios-cloud-upload-outline">Select the file to upload</Button>
            </Upload>
          </div>
          <div class="file-input-item">
            <p>图片链接(需允许跨域的图片地址)</p>
            <Input v-model="value">
              <Button slot="append" icon="ios-search" @click="handleLink()"></Button>
            </Input>
          </div>
        </div>
        <div class="img-show-box">
          <div class="img-box">
            <img :src="imgData1" />
            <p>maxWidth:300 maxHeight:300</p>
          </div>
          <div class="img-box">
            <img :src="imgData2" />
            <p>maxWidth:600 maxHeight:600</p>
          </div>
          <div class="img-box">
            <img :src="imgData3" />
            <p>maxWidth:900 maxHeight:900</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import util from '@/libs/util'
export default {
  name: 'compressImgPage',
  data () {
    return {
      file: null,
      imgData1: '',
      imgData2: '',
      imgData3: '',
      value: ''
    }
  },
  components: {
  },
  computed: {

  },
  methods: {
    handleUpload (file) {
      this.file = file;
      this.compressImg(file, 'file')
      return false;
    },
    handleLink () {
      this.compressImg(this.value, 'link')
    },
    compressImg (file, type) {
      util.compressImg(file, type, { maxWidth: 300, maxHeight: 300 }).then(res => {
        this.imgData1 = res
      })
      util.compressImg(file, type, { maxWidth: 600, maxHeight: 600 }).then(res => {
        this.imgData2 = res
      })
      util.compressImg(file, type, { maxWidth: 900, maxHeight: 900 }).then(res => {
        this.imgData3 = res
      })
    }
  },
  created () {

  },
  mounted () {

  }
}
</script>
<style lang='less' scoped>
.content-item {
  text-align: left;
  padding: 20px;
  p {
    padding-top: 10px;
  }
}
.file-input-box {
  display: flex;
  align-items: center;
}
.file-input-item {
  flex: 1;
  padding: 10px;
}
.img-box {
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 5px;
  margin-bottom: 20px;
}
</style>>
